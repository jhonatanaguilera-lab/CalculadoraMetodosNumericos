package core;
 
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;
 
/**
 * Interpreta una función f(x) ingresada como texto (ej: "x^2 - 2")
 * y la evalúa para cualquier valor de x. Usa la librería exp4j.
 */
public class Evaluador {
 
    private String expresion;
 
    //  Constructor
 
    public Evaluador(String expresion) {
        this.expresion = expresion;
    }
 
    //  Métodos principales
 
    /**
     * Evalúa la expresión para un valor dado de x.
     *
     * @param x  el valor en el que se evalúa f(x)
     * @return   f(x)
     */
    public double evaluar(double x) {
        Expression expr = new ExpressionBuilder(expresion)
                .variable("x")
                .build()
                .setVariable("x", x);
        return expr.evaluate();
    }
 
    /**
     * Verifica si la expresión es sintácticamente válida.
     *
     * @return true si la expresión puede construirse y evaluarse en x=0
     */
    public boolean esValida() {
        try {
            new ExpressionBuilder(expresion)
                    .variable("x")
                    .build()
                    .setVariable("x", 0)
                    .evaluate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
 
    //  Getter
    
    public String getExpresion(){
        return expresion;
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Evaluador destruido: " + expresion);
        } finally {
            super.finalize();
        }
    }
}
