package core;
 
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
 
/**
 * Almacena la salida de cualquier método numérico.
 * Es el objeto que se guarda en archivo mediante Persistencia.
 */
public class Resultado implements Serializable {
 
    private static final long serialVersionUID = 1L;
 
    private String metodoUsado;
    private double valorFinal;
    private int iteraciones;
    private boolean convergio;
    private String mensaje;
    private String fecha;
 
    //  Constructor
 
    public Resultado(String metodoUsado, double valorFinal,
                     int iteraciones, boolean convergio, String mensaje) {
        this.metodoUsado  = metodoUsado;
        this.valorFinal   = valorFinal;
        this.iteraciones  = iteraciones;
        this.convergio    = convergio;
        this.mensaje      = mensaje;
        this.fecha        = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
 
    //  Getters y Setters
 
    public String getMetodoUsado(){
        return metodoUsado;
    }
 
    public double getValorFinal(){
        return valorFinal;
    }
 
    public int  getIteraciones(){
        return iteraciones;
    }
 
    public boolean isConvergio(){
        return convergio;
    }
    
    public String getMensaje(){
        return mensaje;
    }
    
    public String getFecha(){
        return fecha;
    }
    
    
    //  Setters
    public void   setMetodoUsado(String m){
        this.metodoUsado = m;
    }
    public void   setValorFinal(double v){
        this.valorFinal = v;
    }
    public void   setIteraciones(int i){
        this.iteraciones = i;
    }
    public void    setConvergio(boolean c){
        this.convergio = c;
    }
    public void   setMensaje(String m){
        this.mensaje = m;
    }
    public void   setFecha(String f){
        this.fecha = f;
    }
    
    //  toString
 
    @Override
    public String toString() {
        return "[" + fecha + "] " + metodoUsado
                + " | Resultado: " + valorFinal
                + " | Iteraciones: " + iteraciones
                + " | Convergió: " + convergio
                + " | " + mensaje;
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Resultado destruido: " + metodoUsado);
        } finally {
            super.finalize();
        }
    }
}