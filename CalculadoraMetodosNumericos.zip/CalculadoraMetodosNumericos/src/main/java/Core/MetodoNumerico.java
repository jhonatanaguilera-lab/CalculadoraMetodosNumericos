package core;
 
/**
 * Clase base abstracta de toda la jerarquia
 * Define el contrato común que deben cumplir todos los métodos numéricos.
 */
public abstract class MetodoNumerico {
 
    private String nombre;
    private String descripcion;
 
    //Constructor
    
    public MetodoNumerico(String nombre, String descripcion) {
        this.nombre      = nombre;
        this.descripcion = descripcion;
    }
 
    //  Getters
 
    public String getNombre(){
        return nombre;
    }
    public String getDescripcion(){ 
        return descripcion;
    }
 
    //  Método abstracto — cada subclase implementa su algoritmo
 
    /**
     * Ejecuta el método numérico y devuelve un objeto Resultado.
     * Cada subclase concreta implementa su propio algoritmo aquí.
     *
     * @return Resultado con valor final, iteraciones y estado de convergencia
     */
    public abstract Resultado ejecutar();

    
    //  Destructor

    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("MetodoNumerico destruido: " + nombre);
        } finally {
            super.finalize();
        }
    }
}