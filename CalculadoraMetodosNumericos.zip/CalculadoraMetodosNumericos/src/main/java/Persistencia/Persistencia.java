package persistencia;
import core.Resultado;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
 
/*
Maneja el guardado y la carga de objetos Resultado en un archivo binario
'historial.dat'. Si el archivo no existe, lo crea automáticamente.
También maneja la lectura de datos tabulados desde archivos .txt.
*/

public class Persistencia {
    
    private static final String ARCHIVO = "historial.dat";
    //  Guardar un Resultado en historial.dat
    /*
    Agrega un resultado al historial. Si el archivo no existe lo crea.
    Usa AppendingObjectOutputStream para no sobreescribir entradas previas.
    */
    public void guardar(Resultado resultado) {
        File archivo = new File(ARCHIVO); 
        try {
            if (!archivo.exists()) {
                // Archivo nuevo — usar ObjectOutputStream normal
                try (ObjectOutputStream oos =
                             new ObjectOutputStream(new FileOutputStream(archivo))) {
                    oos.writeObject(resultado);
                }
            } else {
                // Archivo existente — usar stream que no reescribe la cabecera
                try (AppendingObjectOutputStream oos =
                             new AppendingObjectOutputStream(new FileOutputStream(archivo, true))) {
                    oos.writeObject(resultado);
                }
            }
        } catch (IOException e) {
            System.err.println("Error al guardar resultado: " + e.getMessage());
        }
    }
 
    //  Cargar todo el historial desde historial.dat

    /*
      Lee todos los objetos Resultado guardados en historial.dat.
      @return lista de Resultado, vacía si el archivo no existe o está vacío
    */
    public List<Resultado> cargarHistorial() {
        List<Resultado> lista = new ArrayList<>();
        File archivo = new File(ARCHIVO);
        if (!archivo.exists()) return lista;
        try (ObjectInputStream ois =
                     new ObjectInputStream(new FileInputStream(archivo))) {
            while (true) {
                try {
                    Resultado r = (Resultado) ois.readObject();
                    lista.add(r);
                } catch (EOFException e) {
                    break;   // fin del archivo, salida normal
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar historial: " + e.getMessage());
        } 
        return lista;
    }
 
    //  Limpiar el historial
    
    //Elimina el archivo historial.dat si existe.
    
    public void limpiarHistorial() {
        File archivo = new File(ARCHIVO);
        if (archivo.exists()) {
            archivo.delete();
            System.out.println("Historial eliminado.");
        }
    }
    //  Leer datos tabulados desde un archivo .txt
    //  Formato esperado: una línea por punto, x e f(x) separados por coma
    //  Ejemplo:
    //      0.0, 0.0
    //      0.25, 0.0625
    //      0.5, 0.25

    /*
       Lee un archivo .txt con datos tabulados y devuelve dos arreglos:
       índice 0:arreglo x[], índice 1:arreglo f(x)[]
       @param rutaArchivo ruta completa al archivo .txt
       @return double[2][] donde [0] es x[] y [1] es fy[], o null si hay error
     */
    public double[][] leerDatosTabulados(String rutaArchivo) {
        List<Double> listaX  = new ArrayList<>();
        List<Double> listaFy = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            int numeroLinea = 0;
            while ((linea = br.readLine()) != null) {
                numeroLinea++;
                linea = linea.trim();
                // Ignorar líneas vacías o comentarios (#)
                if (linea.isEmpty() || linea.startsWith("#")) continue;
                String[] partes = linea.split(",");
                if (partes.length != 2) {
                    System.err.println("Error en línea " + numeroLinea + ": formato incorrecto (esperado: x, f(x))");
                    return null;
                }
                try {
                    double x  = Double.parseDouble(partes[0].trim());
                    double fy = Double.parseDouble(partes[1].trim());
                    listaX.add(x);
                    listaFy.add(fy);
                } catch (NumberFormatException e) {
                    System.err.println("Error en línea " + numeroLinea + ": valor no numérico → " + linea);
                    return null;
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer archivo: " + e.getMessage());
            return null;
        }
        if (listaX.isEmpty()) {
            System.err.println("El archivo no contiene datos.");
            return null;
        }
        // Convertir listas a arreglos primitivos
        double[] x  = new double[listaX.size()];
        double[] fy = new double[listaFy.size()];
        for (int i = 0; i < listaX.size(); i++) {
            x[i]  = listaX.get(i);
            fy[i] = listaFy.get(i);
        }
        return new double[][] { x, fy };
    }
 
    //  Clase interna — evita reescribir la cabecera al hacer append
 
    private static class AppendingObjectOutputStream extends ObjectOutputStream {
        public AppendingObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }
        @Override
        protected void writeStreamHeader() throws IOException {
            // No escribir cabecera al hacer append — el archivo ya la tiene
            reset();
        }
    }
 
    //  Destructor
    
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Persistencia destruida.");
        } finally {
            super.finalize();
        }
    }
}
