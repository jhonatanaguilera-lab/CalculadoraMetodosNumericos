package raices;
 
import core.Resultado;
 
/**
 * Método de Falsa Posición — RUTINA005.
 * Similar a Bisección pero calcula c con la fórmula de la cuerda entre f(a) y f(b).
 * c0 se inicializa automáticamente igual a a.
 */
public class FalsaPosicion extends MetodoRaices {
 
    private double a;
    private double b;
    private double c0;   // inicializado igual a a, convención de la cátedra
 
    //  Constructor

    public FalsaPosicion(String funcion, double a, double b, double tol, int n) {
        super("Falsa Posición",
              "Calcula c con la fórmula de la cuerda entre f(a) y f(b).",
              funcion, tol, n);
        this.a  = a;
        this.b  = b;
        this.c0 = a;   // c0 = a, convención de la cátedra
    }
 
    // Getters
 
    public double getA(){
        return a;
    }

    public double getB(){
        return b;
    }

    public double getC0(){
        return c0;
    }
    
    //Setters
    public void   setA(double a){
        this.a = a;
    }
    public void   setB(double b){
        this.b = b;
    }

    //  Algoritmo — traducción directa de RUTINA005 
    @Override
    public Resultado ejecutar() {
        double tol  = getTol();
        int    n    = getN(); 
        double ai   = this.a;
        double bi   = this.b;
        double c0i  = this.c0;
        double c    = c0i;
        int    iter = 0;
        boolean convergio = false;
        for (int i = 0; i < n; i++) {
            iter++;
            double fa = evaluador.evaluar(ai);
            double fb = evaluador.evaluar(bi);
            c = (bi * fa - ai * fb) / (fa - fb);
            double err    = Math.abs(c0i - c);
            double relerr = Math.abs(err / c);
            if (tol > err || tol > relerr || tol > Math.abs(evaluador.evaluar(c))) {
                convergio = true;
                break;
            } else {
                if (fa * evaluador.evaluar(c) < 0) {
                    bi = c;
                } else {
                    ai = c;
                }
            }
            c0i = c;
        }
 
        String mensaje = convergio ? "El método convergió en " + iter + " iteraciones." : "Se alcanzó el máximo de iteraciones sin convergencia.";
        return new Resultado("Falsa Posición", c, iter, convergio, mensaje);
    }
 
    //  Destructor 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("FalsaPosicion destruida.");
        } finally {
            super.finalize();
        }
    }
}
 