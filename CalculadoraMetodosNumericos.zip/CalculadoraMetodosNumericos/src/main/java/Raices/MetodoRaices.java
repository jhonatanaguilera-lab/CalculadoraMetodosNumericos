package raices;
 
import core.Evaluador;
import core.MetodoNumerico;
import core.Resultado;
 
/**
 * Clase abstracta base para todos los métodos de búsqueda de raíces.
 * Extiende MetodoNumerico y define atributos comunes.
 */
public abstract class MetodoRaices extends MetodoNumerico {
 
    private String funcion;   // expresión ingresada por el usuario
    private double tol;
    private int n;            // máximo de iteraciones, default 100
 
    protected Evaluador evaluador;
 
    //  Constructor
 
    public MetodoRaices(String nombre, String descripcion,String funcion, double tol, int n) {
        super(nombre, descripcion);
        this.funcion = funcion;
        this.tol = tol;
        this.n = n;
        this.evaluador = new Evaluador(funcion);
    }
 
    //  Getters y Setters
 
    public String getFuncion(){ 
        return funcion; 
    }

    public double getTol(){ 
        return tol; 
    }

    public int    getN(){
        return n; 
    }
    
    //Setters
    
    public void   setFuncion(String f){
        this.funcion = f; 
    }
    
    public void   setTol(double t){
        this.tol = t; 
    }
    
    public void   setN(int n){
        this.n = n; 
    }    
 
    //  Método abstracto
 
    @Override
    public abstract Resultado ejecutar();
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("MetodoRaices destruido: " + getNombre());
        } finally {
            super.finalize();
        }
    }
}
 