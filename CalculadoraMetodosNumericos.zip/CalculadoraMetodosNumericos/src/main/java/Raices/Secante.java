package raices; 
import core.Resultado; 
/**
 * Método de la Secante — RUTINA008.
 * No necesita derivada. Usa dos aproximaciones iniciales x0 y x1
 * para construir una recta secante.
 */
public class Secante extends MetodoRaices {
 
    private double x0;
    private double x1;
 
    //  Constructor
 
    public Secante(String funcion, double x0, double x1, double tol, int n) {
        super("Secante","Usa dos aproximaciones iniciales para construir una recta secante.",funcion, tol, n);
        this.x0 = x0;
        this.x1 = x1;
    }
 
    //  Getters y Setters
 
    public double getX0(){
        return x0;
    }

    public double getX1(){
        return x1;
    }
    
    // Setters
    public void   setX0(double x0){
        this.x0 = x0;
    }
    
    public void   setX1(double x1){
        this.x1 = x1;
    }
    
    //  Algoritmo — traducción directa de RUTINA008
    @Override
    public Resultado ejecutar() {
        double tol  = getTol();
        int    n    = getN();
        double x0i  = this.x0;
        double x1i  = this.x1;
        double x2   = x1i;
        int    iter = 0;
        boolean convergio = false;
        for (int i = 0; i < n; i++) {
            iter++;
            double fx0 = evaluador.evaluar(x0i);
            double fx1 = evaluador.evaluar(x1i);
            x2 = (x1i * fx0 - x0i * fx1) / (fx0 - fx1);
            double err    = Math.abs(x2 - x1i);
            double relerr = Math.abs(err / x2);
            if (tol > err || tol > relerr || tol > Math.abs(evaluador.evaluar(x2))) {
                convergio = true;
                break;
            }
            x0i = x1i;
            x1i = x2;
        }
        String mensaje = convergio ? "El método convergió en " + iter + " iteraciones." : "Se alcanzó el máximo de iteraciones sin convergencia.";
        return new Resultado("Secante", x2, iter, convergio, mensaje);
    }
 
    //  Destructor
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Secante destruida.");
        } finally {
            super.finalize();
        }
    }
}
