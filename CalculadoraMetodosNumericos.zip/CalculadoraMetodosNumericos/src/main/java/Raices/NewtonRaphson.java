package raices; 
import core.Evaluador;
import core.Resultado;
/**
 * Método de Newton-Raphson — RUTINA006.
 * Usa la derivada f'(x) para converger más rápido.
 * Requiere que el usuario ingrese también la derivada como texto.
 */
public class NewtonRaphson extends MetodoRaices {
 
    private String   derivada;           // expresión de f'(x)
    private double   p0;                 // aproximación inicial
    private Evaluador evaluadorDerivada;
 
    //  Constructor
    public NewtonRaphson(String funcion, String derivada,double p0, double tol, int n) {
        super("Newton-Raphson","Usa la derivada f'(x) para converger más rápido.",funcion, tol, n);
        this.derivada = derivada;
        this.p0 = p0;
        this.evaluadorDerivada = new Evaluador(derivada);
    }
 
    //  Getters
    public String getDerivada(){
        return derivada;
    }
 
    public double getP0(){
        return p0;
    }
    
    //Setters
    public void   setDerivada(String d){
        this.derivada = d;
    } 
    
    public void   setP0(double p0){
        this.p0 = p0;
    }
    
    //  Algoritmo — traducción directa de RUTINA006
    @Override
    public Resultado ejecutar() {
        double tol  = getTol();
        int    n    = getN();
        double p0i  = this.p0;
        double p    = p0i;
        int    iter = 0;
        boolean convergio = false; 
        for (int i = 0; i < n; i++) {
            iter++;
            p = p0i - evaluador.evaluar(p0i) / evaluadorDerivada.evaluar(p0i);
            double err    = Math.abs(p - p0i);
            double relerr = Math.abs(err / p);
            if (tol > err || tol > relerr || tol > Math.abs(evaluador.evaluar(p))) {
                convergio = true;
                break;
            }
            p0i = p;
        } 
        String mensaje = convergio
                ? "El método convergió en " + iter + " iteraciones."
                : "Se alcanzó el máximo de iteraciones sin convergencia.";
 
        return new Resultado("Newton-Raphson", p, iter, convergio, mensaje);
    }
 
    //  Destructor
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("NewtonRaphson destruido.");
        } finally {
            super.finalize();
        }
    }
}
