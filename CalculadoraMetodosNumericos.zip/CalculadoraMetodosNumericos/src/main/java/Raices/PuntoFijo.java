package raices; 
import core.Evaluador;
import core.Resultado;
 
/**
 * Método de Punto Fijo — RUTINA007.
 * Requiere que el usuario despeje x = g(x) e ingrese g(x)
 * además de f(x) para verificar convergencia.
 */
public class PuntoFijo extends MetodoRaices {
 
    private String    g;              // función de iteración g(x)
    private double    p0;
    private Evaluador evaluadorG;
 
    //  Constructor
 
    public PuntoFijo(String funcion, String g, double p0, double tol, int n) {
        super("Punto Fijo","Itera x = g(x) hasta que f(p) sea suficientemente pequeño.",funcion, tol, n);
        this.g = g;
        this.p0 = p0;
        this.evaluadorG = new Evaluador(g);
    }
 
    //  Getters
    
    public String getG(){
        return g;
    }
 
    public double getP0(){
        return p0;
    }

    //  Setters
    
    public void   setG(String g){
        this.g = g;
    }    
    
    public void   setP0(double p0){
        this.p0 = p0;
    }
    
    //  Algoritmo — traducción directa de RUTINA007 
    
    @Override
    public Resultado ejecutar() {
        double tol  = getTol();
        int    n    = getN();
        double p0i  = this.p0;
        double p    = p0i;
        int    iter = 0;
        boolean convergio = false;
        for (int i = 0; i < n; i++) {
            iter++;
            p = evaluadorG.evaluar(p0i);
            double err    = Math.abs(p - p0i);
            double relerr = Math.abs(err / p);
            if (tol > err || tol > relerr || tol > Math.abs(evaluador.evaluar(p))) {
                convergio = true;
                break;
            }
            p0i = p;
        }
        String mensaje = convergio
                ? "El método convergió en " + iter + " iteraciones."
                : "Se alcanzó el máximo de iteraciones sin convergencia.";
        return new Resultado("Punto Fijo", p, iter, convergio, mensaje);
    }

    //  Destructor 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("PuntoFijo destruido.");
        } finally {
            super.finalize();
        }
    }
}