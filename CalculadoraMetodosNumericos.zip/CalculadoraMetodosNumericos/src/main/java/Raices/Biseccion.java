package raices;
 
import core.Resultado;
 
/**
 * Método de Biseccion, Rutina004
 * Busca la raíz dividiendo el intervalo [a,b] por la mitad en cada iteración.
 * c0 se inicializa automáticamente igual a a.
 */
public class Biseccion extends MetodoRaices {
 
    private double a;    // extremo izquierdo del intervalo
    private double b;    // extremo derecho del intervalo
    private double c0;   // punto medio inicial = a (por convención de la cátedra)
 
    //  Constructor
 
    public Biseccion(String funcion, double a, double b, double tol, int n) {
        super("Bisección",
              "Busca la raíz dividiendo el intervalo [a,b] por la mitad.",
              funcion, tol, n);
        this.a  = a;
        this.b  = b;
        this.c0 = a;   // c0 = a, convención de la cátedra
    }
 
    //  Getters
 
    public double getA(){ 
        return a; 
    }

    public double getB(){
        return b;
    }
 
    public double getC0(){
        return c0; 
    }
    
    //Setters
     public void   setA(double a){ 
        this.a = a; 
    }
     
     public void   setB(double b){
        this.b = b;
    }
     
    //  Algoritmo — traducción directa de RUTINA004
 
    @Override
    public Resultado ejecutar() {
        double tol  = getTol();
        int    n    = getN();
 
        double ai   = this.a;
        double bi   = this.b;
        double c0i  = this.c0;
        double c    = c0i;
        int    iter = 0;
        boolean convergio = false;
 
        for (int i = 0; i < n; i++) {
            iter++;
            c = (ai + bi) / 2.0;
 
            double err    = Math.abs(c0i - c);
            double relerr = Math.abs(err / c);
 
            if (tol > err || tol > relerr || tol > Math.abs(evaluador.evaluar(c))) {
                convergio = true;
                break;
            } else {
                if (evaluador.evaluar(ai) * evaluador.evaluar(c) < 0) {
                    bi = c;
                } else {
                    ai = c;
                }
            }
            c0i = c;
        }
 
        String mensaje = convergio
                ? "El método convergió en " + iter + " iteraciones."
                : "Se alcanzó el máximo de iteraciones sin convergencia.";
 
        return new Resultado("Bisección", c, iter, convergio, mensaje);
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Biseccion destruida.");
        } finally {
            super.finalize();
        }
    }
}
 
