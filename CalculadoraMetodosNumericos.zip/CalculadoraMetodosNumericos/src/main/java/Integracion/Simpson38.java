package integracion;
import core.Evaluador;
import core.Resultado;
 
/**
 * Método de Simpson 3/8 — RUTINA016.
 * Requiere n múltiplo de 3 (modo función) o grupos de 4 puntos con h constante (modo tabulado).
 * Soporta modo función y modo tabulado.
 */
public class Simpson38 extends MetodoIntegracion {
 
    private static final double TOL_H = 1e-10; // tolerancia para comparar pasos
 
    //  Constructores
 
    // Modo función — valida que n sea múltiplo de 3
    public Simpson38(String funcion, double a, double b, int n) {
        super("Simpson 3/8","Aproximación con polinomios de grado 3. Requiere n múltiplo de 3.",funcion, a, b, n);
    }
    //Modo tabulado — valida h constante por grupos de 4 puntos
    public Simpson38(double[] x, double[] fy) {
        super("Simpson 3/8",
              "Aproximación con polinomios de grado 3. Datos tabulados.",
              x, fy);
    }
    //  Algoritmo — traducción directa de RUTINA016
    //  Solo cambia cómo se construye y[] antes del loop
    @Override
    public Resultado ejecutar() {
        double[] y;
        double[] xi;
        if (!modoTabulado) {
            //Validar n múltiplo de 3
            if (n % 3 != 0) {
                return new Resultado("Simpson 3/8", 0, 0, false,
                        "Error: n debe ser múltiplo de 3. Valor ingresado: " + n);
            }
            //Modo función: construir y[] evaluando f(x)
            double h = (b - a) / n;
            Evaluador ev = new Evaluador(funcion);
            y  = new double[n + 1];
            xi = new double[n + 1];
            for (int k = 0; k <= n; k++) {
                xi[k] = a + k * h;
                y[k]  = ev.evaluar(xi[k]);
            }
        } else {
            //Modo tabulado
            y  = this.fy;
            xi = this.x;
            // Validar cantidad de puntos: debe ser de la forma 3m+1 (4, 7, 10, ...)
            if ((y.length - 1) % 3 != 0) {
                return new Resultado("Simpson 3/8", 0, 0, false,
                        "Error: la cantidad de puntos tabulados debe ser 4, 7, 10, ... "
                        + "(múltiplos de 3 + 1). Puntos ingresados: " + y.length);
            }
            // Validar h constante dentro de cada grupo de 4 puntos
            for (int k = 0; k < y.length - 3; k += 3) {
                double h1 = xi[k + 1] - xi[k];
                double h2 = xi[k + 2] - xi[k + 1];
                double h3 = xi[k + 3] - xi[k + 2];
                if (Math.abs(h1 - h2) > TOL_H || Math.abs(h2 - h3) > TOL_H) {
                    return new Resultado("Simpson 3/8", 0, 0, false,
                            "Error: paso h no constante en el grupo de puntos "
                            + (k + 1) + "-" + (k + 2) + "-" + (k + 3) + "-" + (k + 4)
                            + ". h1=" + h1 + ", h2=" + h2 + ", h3=" + h3);
                }
            }
        }
        //Loop de RUTINA016 sin modificaciones
        double A = 0;
        int    k = 0;
        while (k < y.length - 3) {
            double h = xi[k + 1] - xi[k];   // h local del grupo
            A += (3.0 * h / 8.0) * (y[k] + 3 * y[k + 1] + 3 * y[k + 2] + y[k + 3]);
            k += 3;
        }
        return new Resultado("Simpson 3/8", A, 0, true,"Integral aproximada = " + A);
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Simpson38 destruido.");
        } finally {
            super.finalize();
        }
    }
}