package integracion;
import core.MetodoNumerico;
import core.Resultado; 
/**
 * Clase abstracta base para todos los métodos de integración numérica.
 * Extiende MetodoNumerico y define atributos comunes.
 * Soporta modo función y modo tabulado.
 */
public abstract class MetodoIntegracion extends MetodoNumerico {
 
    //Modo función
    protected String  funcion;
    protected double  a;       // límite inferior
    protected double  b;       // límite superior
    protected int     n;       // número de subintervalos
 
    //Modo tabulado
    protected double[] x;      // arreglo de valores x
    protected double[] fy;     // arreglo de valores f(x)
 
    protected boolean modoTabulado;
 
    //Constructor modo función
    
    public MetodoIntegracion(String nombre, String descripcion,String funcion, double a, double b, int n) {
        super(nombre, descripcion);
        this.funcion = funcion;
        this.a = a;
        this.b = b;
        this.n = n;
        this.modoTabulado = false;
    }
 
    //Constructor modo tabulado 
    public MetodoIntegracion(String nombre, String descripcion,double[] x, double[] fy) {
        super(nombre, descripcion);
        this.x = x;
        this.fy = fy;
        this.n = x.length - 1;
        this.modoTabulado = true;
    }
 
    //Getters

    public String   getFuncion(){
        return funcion;
    }
    
    public double   getA(){
        return a;
    }
    
    public double   getB(){
        return b;
    }
    
    public int      getN(){
        return n;
    }
    
    public double[] getX(){
        return x;
    }
    
    public double[] getFy(){
        return fy;
    }
    
    public boolean  isModoTabulado(){
        return modoTabulado;
    }
 
    //  Método abstracto 
    @Override
    public abstract Resultado ejecutar();
 
    //  Destructor
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("MetodoIntegracion destruido: " + getNombre());
        } finally {
            super.finalize();
        }
    }
}