package integracion; 
import core.Evaluador;
import core.Resultado;
 
/**
 * Método de Simpson 1/3 — RUTINA015.
 * Requiere n par (modo función) o grupos de 3 puntos con h constante (modo tabulado).
 * Soporta modo función y modo tabulado.
 */
public class Simpson13 extends MetodoIntegracion {
 
    private static final double TOL_H = 1e-10; // tolerancia para comparar pasos
 
    //  Constructores
    
    //Modo función — valida que n sea par
    public Simpson13(String funcion, double a, double b, int n) {
        super("Simpson 1/3","Aproximación con polinomios de grado 2. Requiere n par.",funcion, a, b, n);
    }
 
    // Modo tabulado, valida h constante por grupos de 3 puntos
    public Simpson13(double[] x, double[] fy) {
        super("Simpson 1/3","Aproximación con polinomios de grado 2. Datos tabulados.",x, fy);
    }
 
    //  Algoritmo — traducción directa de RUTINA015
    //  Solo cambia cómo se construye y[] antes del loop
 
    @Override
    public Resultado ejecutar() {
        double[] y;
        double[] xi;
        if (!modoTabulado) {
            //Validar n par
            if (n % 2 != 0) {
                return new Resultado("Simpson 1/3", 0, 0, false,
                        "Error: n debe ser par. Valor ingresado: " + n);
            }
            // Modo función: construir y[] evaluando f(x)
            double h  = (b - a) / n;
            Evaluador ev = new Evaluador(funcion);
            y  = new double[n + 1];
            xi = new double[n + 1];
            for (int k = 0; k <= n; k++) {
                xi[k] = a + k * h;
                y[k]  = ev.evaluar(xi[k]);
            }
        } else {
            //Modo tabulado
            y  = this.fy;
            xi = this.x;
            // Validar cantidad de puntos: debe ser impar (2m+1 puntos → m grupos de 3)
            if (y.length % 2 == 0) {
                return new Resultado("Simpson 1/3", 0, 0, false,
                        "Error: la cantidad de puntos tabulados debe ser impar "
                        + "(3, 5, 7, ...). Puntos ingresados: " + y.length);
            }
            // Validar h constante dentro de cada grupo de 3 puntos
            for (int k = 0; k < y.length - 2; k += 2) {
                double h1 = xi[k + 1] - xi[k];
                double h2 = xi[k + 2] - xi[k + 1];
                if (Math.abs(h1 - h2) > TOL_H) {
                    return new Resultado("Simpson 1/3", 0, 0, false,
                            "Error: paso h no constante en el grupo de puntos "
                            + (k + 1) + "-" + (k + 2) + "-" + (k + 3)
                            + ". h1=" + h1 + ", h2=" + h2);
                }
            }
        }
        //Loop de RUTINA015 sin modificaciones
        double A = 0;
        int    k = 0;
        while (k < y.length - 2) {
            double h = xi[k + 1] - xi[k];   // h local del grupo
            A += (h / 3.0) * (y[k] + 4 * y[k + 1] + y[k + 2]);
            k += 2;
        }
 
        return new Resultado("Simpson 1/3", A, 0, true,
                "Integral aproximada = " + A);
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Simpson13 destruido.");
        } finally {
            super.finalize();
        }
    }
}