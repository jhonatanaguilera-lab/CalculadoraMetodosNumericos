package integracion; 
import core.Evaluador;
import core.Resultado;
 
/**
 * Método del Trapecio — RUTINA014.
 * Aproxima el área bajo la curva sumando trapecios.
 * Soporta modo función y modo tabulado.
 * En modo tabulado el paso h puede ser no constante (h local por par de puntos).
 */
public class Trapecio extends MetodoIntegracion {
 
    //  Constructores
    
    // Modo función
    public Trapecio(String funcion, double a, double b, int n) {
        super("Trapecio","Aproxima el área sumando trapecios de ancho h = (b-a)/n.",funcion, a, b, n);
    }
    //Modo tabulado — h puede ser no constante
    public Trapecio(double[] x, double[] fy) {
        super("Trapecio", "Aproxima el área sumando trapecios con datos tabulados.",x, fy);
    }
 
    //  Algoritmo — traducción directa de RUTINA014
    //  Solo cambia cómo se construye y[] antes del loop 
    @Override
    public Resultado ejecutar() {
        double[] y;
        double[] xi;
        if (!modoTabulado) {
            // --- Modo función: construir y[] evaluando f(x) ---
            double h = (b - a) / n;
            Evaluador ev = new Evaluador(funcion);
            y  = new double[n + 1];
            xi = new double[n + 1];
            for (int k = 0; k <= n; k++) {
                xi[k] = a + k * h;
                y[k]  = ev.evaluar(xi[k]);
            }
        } else {
            // --- Modo tabulado: y[] ya viene dado ---
            y  = this.fy;
            xi = this.x;
        }
        // Loop de RUTINA014 sin modificaciones
        // h local por cada par de puntos (soporta h no constante)
        double A = 0;
        int    k = 0;
        while (k < y.length - 1) {
            double hk = xi[k + 1] - xi[k];   // h local
            A += (hk / 2.0) * (y[k] + y[k + 1]);
            k++;
        } 
        return new Resultado("Trapecio", A, 0, true,"Integral aproximada = " + A);
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Trapecio destruido.");
        } finally {
            super.finalize();
        }
    }
}
 
