package gui;
 
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
 
/**
 * Ventana principal de la Calculadora de Métodos Numéricos.
 * Contiene el sidebar de navegación y el panel central de contenido.
 * Tema: dark mode negro profundo + azul índigo.
 */
public class VentanaPrincipal extends JFrame {
 
    // ------------------------------------------------------------------ //
    //  Paleta de colores del tema dark
    // ------------------------------------------------------------------ //
 
    public static final Color BG_DEEP       = new Color(0x0D, 0x0D, 0x0F);  // fondo más oscuro
    public static final Color BG_PANEL      = new Color(0x11, 0x13, 0x18);  // fondo de cards
    public static final Color BG_SIDEBAR    = new Color(0x11, 0x13, 0x18);  // fondo sidebar
    public static final Color BG_INPUT      = new Color(0x0D, 0x0D, 0x0F);  // fondo inputs
    public static final Color BG_HOVER      = new Color(0x1A, 0x1F, 0x35);  // hover iconos
    public static final Color BORDER_COLOR  = new Color(0x1E, 0x21, 0x30);  // bordes sutiles
    public static final Color ACCENT_BLUE   = new Color(0x4C, 0x6E, 0xF5);  // azul índigo acento
    public static final Color ACCENT_DIM    = new Color(0x2D, 0x3A, 0x6E);  // azul oscuro (botones)
    public static final Color ACCENT_LIGHT  = new Color(0x74, 0x8F, 0xFC);  // azul claro (textos btn)
    public static final Color TEXT_PRIMARY  = new Color(0xF0, 0xF0, 0xF0);  // texto principal
    public static final Color TEXT_MUTED    = new Color(0x4A, 0x55, 0x68);  // texto apagado
    public static final Color TEXT_LABEL    = new Color(0x8A, 0x9B, 0xB0);  // labels de campos
    public static final Color GREEN_OK      = new Color(0x2F, 0x9E, 0x44);  // convergió
    public static final Color RED_ERR       = new Color(0xE2, 0x4B, 0x4A);  // no convergió
 
    // ------------------------------------------------------------------ //
    //  Componentes principales
    // ------------------------------------------------------------------ //
 
    private JPanel      sidebar;
    private JPanel      contentPanel;
    private CardLayout  cardLayout;
 
    private JButton     btnRaices;
    private JButton     btnIntegracion;
    private JButton     btnSistemas;
    private JButton     btnHistorial;
 
    private PanelRaices      panelRaices;
    private PanelIntegracion panelIntegracion;
    private PanelSistemas    panelSistemas;
    private PanelHistorial   panelHistorial;
 
    // ------------------------------------------------------------------ //
    //  Constructor
    // ------------------------------------------------------------------ //
 
    public VentanaPrincipal() {
        super("Calculadora de Métodos Numéricos");
        configurarVentana();
        construirUI();
        setVisible(true);
    }
 
    // ------------------------------------------------------------------ //
    //  Configuración de la ventana
    // ------------------------------------------------------------------ //
 
    private void configurarVentana() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 660);
        setMinimumSize(new Dimension(860, 580));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DEEP);
 
        // Aplicar look & feel del sistema para mejor integración
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            // Continuar con L&F por defecto si falla
        }
 
        // Personalizar componentes globales de Swing
        UIManager.put("OptionPane.background",        BG_PANEL);
        UIManager.put("Panel.background",             BG_PANEL);
        UIManager.put("OptionPane.messageForeground", TEXT_PRIMARY);
    }
 
    // ------------------------------------------------------------------ //
    //  Construcción de la UI
    // ------------------------------------------------------------------ //
 
    private void construirUI() {
        setLayout(new BorderLayout());
 
        // Sidebar izquierdo
        sidebar = construirSidebar();
        add(sidebar, BorderLayout.WEST);
 
        // Panel central con CardLayout
        cardLayout   = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(BG_DEEP);
 
        panelRaices      = new PanelRaices();
        panelIntegracion = new PanelIntegracion();
        panelSistemas    = new PanelSistemas();
        panelHistorial   = new PanelHistorial();
 
        contentPanel.add(panelRaices,      "raices");
        contentPanel.add(panelIntegracion, "integracion");
        contentPanel.add(panelSistemas,    "sistemas");
        contentPanel.add(panelHistorial,   "historial");
 
        add(contentPanel, BorderLayout.CENTER);
 
        // Mostrar raíces por defecto
        mostrarPanel("raices");
        setActiveButton(btnRaices);
    }
 
    // ------------------------------------------------------------------ //
    //  Sidebar
    // ------------------------------------------------------------------ //
 
    private JPanel construirSidebar() {
        JPanel panel = new JPanel();
        panel.setBackground(BG_SIDEBAR);
        panel.setPreferredSize(new Dimension(64, 0));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(16, 10, 16, 10));
 
        // Borde derecho sutil
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 0, 1, BORDER_COLOR),
            new EmptyBorder(16, 10, 16, 10)
        ));
 
        // Logo / ícono de la app
        JLabel logo = new JLabel("\u222B", SwingConstants.CENTER);
        logo.setFont(new Font("Serif", Font.BOLD, 22));
        logo.setForeground(ACCENT_BLUE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        logo.setMaximumSize(new Dimension(44, 44));
        panel.add(logo);
        panel.add(Box.createVerticalStrut(20));
 
        // Separador
        panel.add(crearSeparador());
        panel.add(Box.createVerticalStrut(12));
 
        // Botones de navegación
        btnRaices      = crearBotonSidebar("f(x)", "Raíces de ecuaciones");
        btnIntegracion = crearBotonSidebar("\u222B",  "Integración numérica");
        btnSistemas    = crearBotonSidebar("Ax",    "Sistemas lineales");
 
        panel.add(btnRaices);
        panel.add(Box.createVerticalStrut(6));
        panel.add(btnIntegracion);
        panel.add(Box.createVerticalStrut(6));
        panel.add(btnSistemas);
 
        // Empujar historial al fondo
        panel.add(Box.createVerticalGlue());
        panel.add(crearSeparador());
        panel.add(Box.createVerticalStrut(12));
 
        btnHistorial = crearBotonSidebar("\u29C9", "Historial");
        panel.add(btnHistorial);
 
        // Eventos de navegación
        btnRaices.addActionListener(e -> {
            mostrarPanel("raices");
            setActiveButton(btnRaices);
        });
        btnIntegracion.addActionListener(e -> {
            mostrarPanel("integracion");
            setActiveButton(btnIntegracion);
        });
        btnSistemas.addActionListener(e -> {
            mostrarPanel("sistemas");
            setActiveButton(btnSistemas);
        });
        btnHistorial.addActionListener(e -> {
            panelHistorial.recargar();
            mostrarPanel("historial");
            setActiveButton(btnHistorial);
        });
 
        return panel;
    }
 
    private JButton crearBotonSidebar(String texto, String tooltip) {
        JButton btn = new JButton(texto);
        btn.setToolTipText(tooltip);
        btn.setFont(new Font("Serif", Font.PLAIN, 13));
        btn.setForeground(TEXT_MUTED);
        btn.setBackground(BG_SIDEBAR);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 6, 8, 6));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(44, 44));
        btn.setPreferredSize(new Dimension(44, 44));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setOpaque(true);
 
        // Hover effect
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (!btn.getBackground().equals(BG_HOVER)) {
                    btn.setBackground(new Color(0x1A, 0x1F, 0x35));
                }
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (!btn.getBackground().equals(BG_HOVER)) {
                    btn.setBackground(BG_SIDEBAR);
                }
            }
        });
 
        return btn;
    }
 
    private JSeparator crearSeparador() {
        JSeparator sep = new JSeparator(SwingConstants.HORIZONTAL);
        sep.setForeground(BORDER_COLOR);
        sep.setBackground(BORDER_COLOR);
        sep.setMaximumSize(new Dimension(44, 1));
        return sep;
    }
 
    // ------------------------------------------------------------------ //
    //  Gestión de panel activo
    // ------------------------------------------------------------------ //
 
    private void mostrarPanel(String nombre) {
        cardLayout.show(contentPanel, nombre);
    }
 
    private void setActiveButton(JButton activo) {
        for (JButton btn : new JButton[]{btnRaices, btnIntegracion, btnSistemas, btnHistorial}) {
            btn.setBackground(BG_SIDEBAR);
            btn.setForeground(TEXT_MUTED);
        }
        activo.setBackground(BG_HOVER);
        activo.setForeground(ACCENT_BLUE);
    }
 
    // ------------------------------------------------------------------ //
    //  Main — punto de entrada de la aplicación
    // ------------------------------------------------------------------ //
 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal());
    }
 
    // ------------------------------------------------------------------ //
    //  Destructor
    // ------------------------------------------------------------------ //
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("VentanaPrincipal destruida.");
        } finally {
            super.finalize();
        }
    }
}