package gui;
 
import core.Resultado;
import persistencia.Persistencia;
 
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
 
/**
 * Panel de Historial.
 * Muestra todos los resultados guardados en historial.dat en una tabla.
 * Permite limpiar el historial.
 */
public class PanelHistorial extends JPanel {
 
    // ------------------------------------------------------------------ //
    //  Componentes
    // ------------------------------------------------------------------ //
 
    private JTable            tabla;
    private DefaultTableModel modelo;
    private JLabel            lblConteo;
 
    private final Persistencia persistencia = new Persistencia();
 
    // Columnas de la tabla
    private static final String[] COLUMNAS = {
        "#", "Fecha", "Método", "Resultado", "Iteraciones", "Convergió", "Mensaje"
    };
 
    // ------------------------------------------------------------------ //
    //  Constructor
    // ------------------------------------------------------------------ //
 
    public PanelHistorial() {
        setBackground(VentanaPrincipal.BG_DEEP);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20, 20, 20, 20));
        construirUI();
    }
 
    // ------------------------------------------------------------------ //
    //  Construcción de la UI
    // ------------------------------------------------------------------ //
 
    private void construirUI() {
 
        // --- Encabezado ---
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(VentanaPrincipal.BG_DEEP);
        encabezado.setBorder(new EmptyBorder(0, 0, 16, 0));
 
        JLabel titulo = new JLabel("Historial de cálculos");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(VentanaPrincipal.TEXT_PRIMARY);
 
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        acciones.setBackground(VentanaPrincipal.BG_DEEP);
 
        lblConteo = new JLabel("0 registros");
        lblConteo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblConteo.setForeground(VentanaPrincipal.TEXT_MUTED);
 
        JButton btnRecargar = crearBotonSecundario("↻  Recargar");
        JButton btnLimpiar  = crearBotonPeligro("Limpiar historial");
 
        acciones.add(lblConteo);
        acciones.add(btnRecargar);
        acciones.add(btnLimpiar);
 
        encabezado.add(titulo,   BorderLayout.WEST);
        encabezado.add(acciones, BorderLayout.EAST);
        add(encabezado, BorderLayout.NORTH);
 
        // --- Tabla ---
        modelo = new DefaultTableModel(COLUMNAS, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;   // tabla de solo lectura
            }
        };
 
        tabla = new JTable(modelo);
        estilizarTabla();
 
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1));
        scroll.getViewport().setBackground(VentanaPrincipal.BG_PANEL);
        scroll.setBackground(VentanaPrincipal.BG_PANEL);
        add(scroll, BorderLayout.CENTER);
 
        // --- Pie: detalle del registro seleccionado ---
        JPanel pie = construirPie();
        add(pie, BorderLayout.SOUTH);
 
        // --- Eventos ---
        btnRecargar.addActionListener(e -> recargar());
        btnLimpiar.addActionListener(e -> confirmarLimpiar());
 
        // Al seleccionar una fila mostrar detalle
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) mostrarDetalle();
        });
 
        // Cargar al iniciar
        recargar();
    }
 
    // ------------------------------------------------------------------ //
    //  Panel pie — detalle del registro seleccionado
    // ------------------------------------------------------------------ //
 
    private JTextArea areaDetalle;
 
    private JPanel construirPie() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(VentanaPrincipal.BG_PANEL);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, VentanaPrincipal.BORDER_COLOR),
            new EmptyBorder(12, 16, 12, 16)
        ));
        panel.setPreferredSize(new Dimension(0, 80));
 
        JLabel lblTit = new JLabel("Detalle");
        lblTit.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblTit.setForeground(VentanaPrincipal.TEXT_MUTED);
        panel.add(lblTit, BorderLayout.NORTH);
 
        areaDetalle = new JTextArea(2, 0);
        areaDetalle.setBackground(VentanaPrincipal.BG_PANEL);
        areaDetalle.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        areaDetalle.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaDetalle.setBorder(null);
        areaDetalle.setEditable(false);
        areaDetalle.setLineWrap(true);
        areaDetalle.setWrapStyleWord(true);
        areaDetalle.setText("Seleccioná un registro para ver el detalle.");
        panel.add(areaDetalle, BorderLayout.CENTER);
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Cargar / recargar historial
    // ------------------------------------------------------------------ //
 
    public void recargar() {
        modelo.setRowCount(0);
        List<Resultado> lista = persistencia.cargarHistorial();
 
        for (int i = 0; i < lista.size(); i++) {
            Resultado r = lista.get(i);
            modelo.addRow(new Object[]{
                i + 1,
                r.getFecha(),
                r.getMetodoUsado(),
                String.format("%.10f", r.getValorFinal()),
                r.getIteraciones() > 0 ? r.getIteraciones() : "—",
                r.isConvergio() ? "Sí" : "No",
                r.getMensaje()
            });
        }
 
        int total = lista.size();
        lblConteo.setText(total + (total == 1 ? " registro" : " registros"));
        areaDetalle.setText("Seleccioná un registro para ver el detalle.");
    }
 
    // ------------------------------------------------------------------ //
    //  Mostrar detalle de la fila seleccionada
    // ------------------------------------------------------------------ //
 
    private void mostrarDetalle() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) return;
 
        String fecha    = (String) modelo.getValueAt(fila, 1);
        String metodo   = (String) modelo.getValueAt(fila, 2);
        String resultado = (String) modelo.getValueAt(fila, 3);
        Object iter     = modelo.getValueAt(fila, 4);
        String convergio = (String) modelo.getValueAt(fila, 5);
        String mensaje  = (String) modelo.getValueAt(fila, 6);
 
        areaDetalle.setText(
            fecha + "  ·  " + metodo +
            "  ·  Resultado: " + resultado +
            "  ·  Iteraciones: " + iter +
            "  ·  Convergió: " + convergio +
            "\n" + mensaje
        );
    }
 
    // ------------------------------------------------------------------ //
    //  Confirmar y limpiar historial
    // ------------------------------------------------------------------ //
 
    private void confirmarLimpiar() {
        int opcion = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que querés eliminar todo el historial?\nEsta acción no se puede deshacer.",
            "Confirmar limpieza",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
 
        if (opcion == JOptionPane.YES_OPTION) {
            persistencia.limpiarHistorial();
            recargar();
        }
    }
 
    // ------------------------------------------------------------------ //
    //  Estilo de la tabla
    // ------------------------------------------------------------------ //
 
    private void estilizarTabla() {
        tabla.setBackground(VentanaPrincipal.BG_PANEL);
        tabla.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabla.setRowHeight(30);
        tabla.setGridColor(VentanaPrincipal.BORDER_COLOR);
        tabla.setSelectionBackground(VentanaPrincipal.BG_HOVER);
        tabla.setSelectionForeground(VentanaPrincipal.ACCENT_BLUE);
        tabla.setShowGrid(true);
        tabla.setIntercellSpacing(new Dimension(1, 1));
        tabla.setFillsViewportHeight(true);
 
        // Encabezado
        JTableHeader header = tabla.getTableHeader();
        header.setBackground(VentanaPrincipal.BG_DEEP);
        header.setForeground(VentanaPrincipal.TEXT_LABEL);
        header.setFont(new Font("SansSerif", Font.PLAIN, 11));
        header.setBorder(BorderFactory.createMatteBorder(
            0, 0, 1, 0, VentanaPrincipal.BORDER_COLOR));
        header.setReorderingAllowed(false);
 
        // Anchos de columna
        tabla.getColumnModel().getColumn(0).setPreferredWidth(30);   // #
        tabla.getColumnModel().getColumn(1).setPreferredWidth(140);  // Fecha
        tabla.getColumnModel().getColumn(2).setPreferredWidth(110);  // Método
        tabla.getColumnModel().getColumn(3).setPreferredWidth(130);  // Resultado
        tabla.getColumnModel().getColumn(4).setPreferredWidth(70);   // Iteraciones
        tabla.getColumnModel().getColumn(5).setPreferredWidth(70);   // Convergió
        tabla.getColumnModel().getColumn(6).setPreferredWidth(250);  // Mensaje
 
        // Renderer con colores para la columna "Convergió"
        tabla.getColumnModel().getColumn(5).setCellRenderer(
            new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(
                        JTable t, Object value, boolean selected,
                        boolean focused, int row, int col) {
                    super.getTableCellRendererComponent(t, value, selected, focused, row, col);
                    setHorizontalAlignment(SwingConstants.CENTER);
                    setBackground(selected
                        ? VentanaPrincipal.BG_HOVER
                        : VentanaPrincipal.BG_PANEL);
                    if ("Sí".equals(value)) {
                        setForeground(VentanaPrincipal.GREEN_OK);
                    } else if ("No".equals(value)) {
                        setForeground(VentanaPrincipal.RED_ERR);
                    } else {
                        setForeground(VentanaPrincipal.TEXT_MUTED);
                    }
                    return this;
                }
            }
        );
 
        // Renderer general para el resto de columnas
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean selected,
                    boolean focused, int row, int col) {
                super.getTableCellRendererComponent(t, value, selected, focused, row, col);
                setBackground(selected
                    ? VentanaPrincipal.BG_HOVER
                    : VentanaPrincipal.BG_PANEL);
                setForeground(selected
                    ? VentanaPrincipal.ACCENT_BLUE
                    : VentanaPrincipal.TEXT_PRIMARY);
                setBorder(new EmptyBorder(0, 8, 0, 8));
                return this;
            }
        };
 
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            if (i != 5) tabla.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
    }
 
    // ------------------------------------------------------------------ //
    //  Helpers de estilo
    // ------------------------------------------------------------------ //
 
    private JButton crearBotonSecundario(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(VentanaPrincipal.BG_HOVER);
        btn.setForeground(VentanaPrincipal.TEXT_LABEL);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(6, 14, 6, 14)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0x1E, 0x21, 0x30));
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(VentanaPrincipal.BG_HOVER);
            }
        });
        return btn;
    }
 
    private JButton crearBotonPeligro(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(new Color(0x2A, 0x10, 0x10));
        btn.setForeground(VentanaPrincipal.RED_ERR);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0x4A, 0x1A, 0x1A), 1),
            new EmptyBorder(6, 14, 6, 14)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0x3A, 0x15, 0x15));
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(new Color(0x2A, 0x10, 0x10));
            }
        });
        return btn;
    }
 
    // ------------------------------------------------------------------ //
    //  Destructor
    // ------------------------------------------------------------------ //
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("PanelHistorial destruido.");
        } finally {
            super.finalize();
        }
    }
}
