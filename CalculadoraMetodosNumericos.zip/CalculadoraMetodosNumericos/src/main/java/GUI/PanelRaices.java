package gui;
 
import core.Resultado;
import persistencia.Persistencia;
import raices.*;
 
import org.jfree.chart.*;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.*;
 
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
 
/**
 * Panel de Raíces de Ecuaciones.
 * Pestaña "Calcular": formulario de parámetros + resultado + guía de sintaxis.
 * Pestaña "Gráfica": gráfica de f(x) con la raíz marcada.
 */
public class PanelRaices extends JPanel {
 
    // ------------------------------------------------------------------ //
    //  Componentes del formulario
    // ------------------------------------------------------------------ //
 
    private JComboBox<String> comboMetodo;
    private JTextField        txtFuncion;
    private JTextField        txtDerivada;   // solo Newton-Raphson
    private JTextField        txtG;          // solo Punto Fijo
    private JTextField        txtA;          // Bisección / Falsa Posición
    private JTextField        txtB;          // Bisección / Falsa Posición
    private JTextField        txtP0;         // Newton / Punto Fijo
    private JTextField        txtX0;         // Secante
    private JTextField        txtX1;         // Secante
    private JTextField        txtTol;
    private JTextField        txtN;
 
    // Panel dinámico de parámetros específicos
    private JPanel panelParams;
 
    // Resultado
    private JLabel lblResultadoVal;
    private JLabel lblFuncionTomada;
    private JLabel lblMensaje;
    private JLabel lblChipConvergio;
    private JLabel lblChipIter;
 
    // Gráfica
    private ChartPanel chartPanel;
    private Resultado  ultimoResultado;
 
    private final Persistencia persistencia = new Persistencia();
 
    // ------------------------------------------------------------------ //
    //  Constructor
    // ------------------------------------------------------------------ //
 
    public PanelRaices() {
        setBackground(VentanaPrincipal.BG_DEEP);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20, 20, 20, 20));
        construirUI();
    }
 
    // ------------------------------------------------------------------ //
    //  Construcción de la UI
    // ------------------------------------------------------------------ //
 
    private void construirUI() {
        JLabel titulo = new JLabel("Raíces de ecuaciones");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        titulo.setBorder(new EmptyBorder(0, 0, 16, 0));
        add(titulo, BorderLayout.NORTH);
 
        JTabbedPane tabs = new JTabbedPane();
        estilizarTabs(tabs);
        tabs.addTab("  Calcular  ", construirPestanaCalcular());
        tabs.addTab("  Gráfica   ", construirPestanaGrafica());
        add(tabs, BorderLayout.CENTER);
    }
 
    // ------------------------------------------------------------------ //
    //  Pestaña Calcular
    // ------------------------------------------------------------------ //
 
    private JPanel construirPestanaCalcular() {
        JPanel panel = new JPanel(new BorderLayout(16, 0));
        panel.setBackground(VentanaPrincipal.BG_DEEP);
        panel.setBorder(new EmptyBorder(16, 0, 0, 0));
 
        // --- Columna izquierda: formulario ---
        JPanel formulario = new JPanel();
        formulario.setBackground(VentanaPrincipal.BG_PANEL);
        formulario.setLayout(new BoxLayout(formulario, BoxLayout.Y_AXIS));
        formulario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(16, 16, 16, 16)
        ));
 
        // Selector de método
        formulario.add(crearLabel("Método"));
        formulario.add(Box.createVerticalStrut(4));
        String[] metodos = {"Newton-Raphson", "Bisección", "Falsa Posición", "Punto Fijo", "Secante"};
        comboMetodo = new JComboBox<>(metodos);
        estilizarCombo(comboMetodo);
        formulario.add(comboMetodo);
        formulario.add(Box.createVerticalStrut(12));
 
        // f(x)
        formulario.add(crearLabel("f(x)"));
        formulario.add(Box.createVerticalStrut(4));
        txtFuncion = crearInput("ej: x^3 - x - 2");
        formulario.add(txtFuncion);
        formulario.add(Box.createVerticalStrut(12));
 
        // Panel dinámico de parámetros según método
        panelParams = new JPanel();
        panelParams.setBackground(VentanaPrincipal.BG_PANEL);
        panelParams.setLayout(new BoxLayout(panelParams, BoxLayout.Y_AXIS));
        formulario.add(panelParams);
 
        // tol y n en una fila
        formulario.add(Box.createVerticalStrut(4));
        JPanel filaTolN = new JPanel(new GridLayout(1, 2, 10, 0));
        filaTolN.setBackground(VentanaPrincipal.BG_PANEL);
        filaTolN.setAlignmentX(Component.LEFT_ALIGNMENT);
        filaTolN.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
 
        JPanel colTol = new JPanel(new BorderLayout(0, 4));
        colTol.setBackground(VentanaPrincipal.BG_PANEL);
        colTol.add(crearLabel("Tolerancia"), BorderLayout.NORTH);
        txtTol = crearInput("ej: 1e-6");
        colTol.add(txtTol, BorderLayout.CENTER);
 
        JPanel colN = new JPanel(new BorderLayout(0, 4));
        colN.setBackground(VentanaPrincipal.BG_PANEL);
        colN.add(crearLabel("Máx. iteraciones"), BorderLayout.NORTH);
        txtN = crearInput("100");
        colN.add(txtN, BorderLayout.CENTER);
 
        filaTolN.add(colTol);
        filaTolN.add(colN);
        formulario.add(filaTolN);
        formulario.add(Box.createVerticalStrut(16));
 
        // Botón ejecutar
        JButton btnEjecutar = crearBotonPrimario("▶   Ejecutar");
        formulario.add(btnEjecutar);
        formulario.add(Box.createVerticalGlue());
 
        // --- Columna derecha: resultado + guía ---
        JPanel panelResultado = construirPanelResultado();
 
        panel.add(formulario,     BorderLayout.WEST);
        panel.add(panelResultado, BorderLayout.CENTER);
 
        // Inicializar campos según método seleccionado
        comboMetodo.addActionListener(e -> actualizarCampos());
        actualizarCampos();
 
        btnEjecutar.addActionListener(e -> ejecutar());
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Actualizar campos dinámicos según método elegido
    // ------------------------------------------------------------------ //
 
    private void actualizarCampos() {
        panelParams.removeAll();
        String metodo = (String) comboMetodo.getSelectedItem();
 
        switch (metodo) {
            case "Newton-Raphson" -> {
                panelParams.add(crearLabel("f'(x)  —  derivada"));
                panelParams.add(Box.createVerticalStrut(4));
                txtDerivada = crearInput("ej: 3*x^2 - 1");
                panelParams.add(txtDerivada);
                panelParams.add(Box.createVerticalStrut(12));
                panelParams.add(crearLabel("p\u2080  —  aproximación inicial"));
                panelParams.add(Box.createVerticalStrut(4));
                txtP0 = crearInput("ej: 1.5");
                panelParams.add(txtP0);
                panelParams.add(Box.createVerticalStrut(12));
            }
            case "Bisección", "Falsa Posición" -> {
                JPanel filaAB = new JPanel(new GridLayout(1, 2, 10, 0));
                filaAB.setBackground(VentanaPrincipal.BG_PANEL);
                filaAB.setAlignmentX(Component.LEFT_ALIGNMENT);
                filaAB.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
 
                JPanel colA = new JPanel(new BorderLayout(0, 4));
                colA.setBackground(VentanaPrincipal.BG_PANEL);
                colA.add(crearLabel("a  —  extremo izquierdo"), BorderLayout.NORTH);
                txtA = crearInput("ej: 1.0");
                colA.add(txtA, BorderLayout.CENTER);
 
                JPanel colB = new JPanel(new BorderLayout(0, 4));
                colB.setBackground(VentanaPrincipal.BG_PANEL);
                colB.add(crearLabel("b  —  extremo derecho"), BorderLayout.NORTH);
                txtB = crearInput("ej: 2.0");
                colB.add(txtB, BorderLayout.CENTER);
 
                filaAB.add(colA);
                filaAB.add(colB);
                panelParams.add(filaAB);
                panelParams.add(Box.createVerticalStrut(12));
            }
            case "Punto Fijo" -> {
                panelParams.add(crearLabel("g(x)  —  función de iteración  x = g(x)"));
                panelParams.add(Box.createVerticalStrut(4));
                txtG = crearInput("ej: (x + 2)^(1/3)");
                panelParams.add(txtG);
                panelParams.add(Box.createVerticalStrut(12));
                panelParams.add(crearLabel("p\u2080  —  aproximación inicial"));
                panelParams.add(Box.createVerticalStrut(4));
                txtP0 = crearInput("ej: 1.5");
                panelParams.add(txtP0);
                panelParams.add(Box.createVerticalStrut(12));
            }
            case "Secante" -> {
                JPanel filaX = new JPanel(new GridLayout(1, 2, 10, 0));
                filaX.setBackground(VentanaPrincipal.BG_PANEL);
                filaX.setAlignmentX(Component.LEFT_ALIGNMENT);
                filaX.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
 
                JPanel colX0 = new JPanel(new BorderLayout(0, 4));
                colX0.setBackground(VentanaPrincipal.BG_PANEL);
                colX0.add(crearLabel("x\u2080"), BorderLayout.NORTH);
                txtX0 = crearInput("ej: 1.0");
                colX0.add(txtX0, BorderLayout.CENTER);
 
                JPanel colX1 = new JPanel(new BorderLayout(0, 4));
                colX1.setBackground(VentanaPrincipal.BG_PANEL);
                colX1.add(crearLabel("x\u2081"), BorderLayout.NORTH);
                txtX1 = crearInput("ej: 2.0");
                colX1.add(txtX1, BorderLayout.CENTER);
 
                filaX.add(colX0);
                filaX.add(colX1);
                panelParams.add(filaX);
                panelParams.add(Box.createVerticalStrut(12));
            }
        }
 
        panelParams.revalidate();
        panelParams.repaint();
    }
 
    // ------------------------------------------------------------------ //
    //  Panel de resultado + guía de sintaxis
    // ------------------------------------------------------------------ //
 
    private JPanel construirPanelResultado() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBackground(VentanaPrincipal.BG_PANEL);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(16, 16, 16, 16)
        ));
 
        // --- Parte superior: resultado ---
        JPanel panelRes = new JPanel();
        panelRes.setBackground(VentanaPrincipal.BG_PANEL);
        panelRes.setLayout(new BoxLayout(panelRes, BoxLayout.Y_AXIS));
 
        JLabel tit = crearLabel("Resultado");
        tit.setFont(new Font("SansSerif", Font.BOLD, 13));
        panelRes.add(tit);
        panelRes.add(Box.createVerticalStrut(12));
 
        panelRes.add(crearLabel("Raíz encontrada"));
        panelRes.add(Box.createVerticalStrut(6));
 
        lblResultadoVal = new JLabel("—");
        lblResultadoVal.setFont(new Font("Monospaced", Font.BOLD, 22));
        lblResultadoVal.setForeground(VentanaPrincipal.ACCENT_BLUE);
        panelRes.add(lblResultadoVal);
        panelRes.add(Box.createVerticalStrut(12));
 
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        chips.setBackground(VentanaPrincipal.BG_PANEL);
        lblChipConvergio = crearChip("—", VentanaPrincipal.BG_PANEL, VentanaPrincipal.TEXT_MUTED);
        lblChipIter      = crearChip("—", VentanaPrincipal.BG_PANEL, VentanaPrincipal.TEXT_MUTED);
        chips.add(lblChipConvergio);
        chips.add(lblChipIter);
        panelRes.add(chips);
        panelRes.add(Box.createVerticalStrut(8));
 
        lblMensaje = new JLabel(" ");
        lblMensaje.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblMensaje.setForeground(VentanaPrincipal.TEXT_LABEL);
        panelRes.add(lblMensaje);
        panelRes.add(Box.createVerticalStrut(10));
 
        panelRes.add(crearLabel("Función evaluada"));
        panelRes.add(Box.createVerticalStrut(4));
        lblFuncionTomada = new JLabel("—");
        lblFuncionTomada.setFont(new Font("Monospaced", Font.PLAIN, 13));
        lblFuncionTomada.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        panelRes.add(lblFuncionTomada);
 
        panel.add(panelRes, BorderLayout.NORTH);
 
        // --- Parte inferior: guía de sintaxis ---
        panel.add(construirGuiaSintaxis(), BorderLayout.CENTER);
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Guía de sintaxis
    // ------------------------------------------------------------------ //
 
    private JPanel construirGuiaSintaxis() {
        JPanel panel = new JPanel();
        panel.setBackground(VentanaPrincipal.BG_DEEP);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(14, 14, 14, 14)
        ));
 
        JLabel titGuia = new JLabel("Guía de sintaxis  —  cómo escribir f(x)");
        titGuia.setFont(new Font("SansSerif", Font.BOLD, 12));
        titGuia.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        titGuia.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(titGuia);
        panel.add(Box.createVerticalStrut(12));
 
        String[][] operadores = {
            { "+  /  -",  "Suma, división, resta",        "x^2 + 3*x - 1"    },
            { "*",        "Multiplicación",                "2*x  o  2*(x+1)"  },
            { "^",        "Potencia",                      "x^3  o  x^0.5"    },
            { "sqrt(x)",  "Raíz cuadrada",                 "sqrt(x^2 - 4)"    },
            { "sin(x)",   "Seno  (radianes)",              "sin(x) - 0.5"     },
            { "cos(x)",   "Coseno  (radianes)",            "cos(x) + x"       },
            { "tan(x)",   "Tangente  (radianes)",          "tan(x) - 1"       },
            { "exp(x)",   "Número e elevado a x",          "exp(x) - 3"       },
            { "log(x)",   "Logaritmo natural  ln(x)",      "log(x) - 1"       },
            { "log10(x)", "Logaritmo base 10",             "log10(x) - 2"     },
            { "abs(x)",   "Valor absoluto",                "abs(x - 2) - 1"   },
            { "pi",       "Constante \u03c0 \u2248 3.14159",  "sin(pi*x)"        },
            { "e",        "Constante e \u2248 2.71828",        "e^x  o  exp(1)*x" },
        };
 
        for (String[] fila : operadores) {
            panel.add(crearFilaGuia(fila[0], fila[1], fila[2]));
            panel.add(Box.createVerticalStrut(5));
        }
 
        panel.add(Box.createVerticalStrut(8));
 
        JLabel nota1 = new JLabel(
            "\u26a0  Siempre escribí el operador *  entre número y variable:  2*x  no  2x");
        nota1.setFont(new Font("SansSerif", Font.ITALIC, 11));
        nota1.setForeground(new Color(0xE2, 0xA0, 0x2A));
        nota1.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(nota1);
        panel.add(Box.createVerticalStrut(4));
 
        JLabel nota2 = new JLabel(
            "\u26a0  Los ángulos de sin, cos y tan deben estar en radianes,  no en grados");
        nota2.setFont(new Font("SansSerif", Font.ITALIC, 11));
        nota2.setForeground(new Color(0xE2, 0xA0, 0x2A));
        nota2.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(nota2);
 
        return panel;
    }
 
    private JPanel crearFilaGuia(String sintaxis, String descripcion, String ejemplo) {
        JPanel fila = new JPanel(new GridLayout(1, 3, 10, 0));
        fila.setBackground(VentanaPrincipal.BG_DEEP);
        fila.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        fila.setAlignmentX(Component.LEFT_ALIGNMENT);
 
        JLabel lblSintaxis = new JLabel(sintaxis);
        lblSintaxis.setFont(new Font("Monospaced", Font.BOLD, 12));
        lblSintaxis.setForeground(VentanaPrincipal.ACCENT_BLUE);
 
        JLabel lblDesc = new JLabel(descripcion);
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblDesc.setForeground(VentanaPrincipal.TEXT_LABEL);
 
        JLabel lblEj = new JLabel(ejemplo);
        lblEj.setFont(new Font("Monospaced", Font.PLAIN, 11));
        lblEj.setForeground(VentanaPrincipal.TEXT_MUTED);
 
        fila.add(lblSintaxis);
        fila.add(lblDesc);
        fila.add(lblEj);
 
        return fila;
    }
 
    // ------------------------------------------------------------------ //
    //  Pestaña Gráfica
    // ------------------------------------------------------------------ //
 
    private JPanel construirPestanaGrafica() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(VentanaPrincipal.BG_DEEP);
        panel.setBorder(new EmptyBorder(16, 0, 0, 0));
 
        JPanel controles = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        controles.setBackground(VentanaPrincipal.BG_DEEP);
        controles.add(crearLabel("x min:"));
        JTextField txtXMin = crearInputPequeno("-5");
        controles.add(txtXMin);
        controles.add(crearLabel("x max:"));
        JTextField txtXMax = crearInputPequeno("5");
        controles.add(txtXMax);
        JButton btnGraficar = crearBotonPrimario("Graficar");
        controles.add(btnGraficar);
        panel.add(controles, BorderLayout.NORTH);
 
        chartPanel = new ChartPanel(null);
        chartPanel.setBackground(VentanaPrincipal.BG_PANEL);
        chartPanel.setBorder(BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1));
        panel.add(chartPanel, BorderLayout.CENTER);
 
        btnGraficar.addActionListener(e -> {
            try {
                double xMin = Double.parseDouble(txtXMin.getText().trim());
                double xMax = Double.parseDouble(txtXMax.getText().trim());
                graficar(xMin, xMax);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                    "Ingresá valores numéricos válidos para el rango.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Lógica de ejecución
    // ------------------------------------------------------------------ //
 
    private void ejecutar() {
        try {
            String metodo  = (String) comboMetodo.getSelectedItem();
            String funcion = txtFuncion.getText().trim();
            double tol     = Double.parseDouble(txtTol.getText().trim());
            int    n       = Integer.parseInt(txtN.getText().trim());
 
            if (funcion.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Ingresá f(x).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
 
            MetodoRaices metodoObj = null;
 
            switch (metodo) {
                case "Newton-Raphson" -> {
                    String derivada = txtDerivada.getText().trim();
                    double p0       = Double.parseDouble(txtP0.getText().trim());
                    metodoObj = new NewtonRaphson(funcion, derivada, p0, tol, n);
                }
                case "Bisección" -> {
                    double a = Double.parseDouble(txtA.getText().trim());
                    double b = Double.parseDouble(txtB.getText().trim());
                    metodoObj = new Biseccion(funcion, a, b, tol, n);
                }
                case "Falsa Posición" -> {
                    double a = Double.parseDouble(txtA.getText().trim());
                    double b = Double.parseDouble(txtB.getText().trim());
                    metodoObj = new FalsaPosicion(funcion, a, b, tol, n);
                }
                case "Punto Fijo" -> {
                    String g  = txtG.getText().trim();
                    double p0 = Double.parseDouble(txtP0.getText().trim());
                    metodoObj = new PuntoFijo(funcion, g, p0, tol, n);
                }
                case "Secante" -> {
                    double x0 = Double.parseDouble(txtX0.getText().trim());
                    double x1 = Double.parseDouble(txtX1.getText().trim());
                    metodoObj = new Secante(funcion, x0, x1, tol, n);
                }
            }
 
            if (metodoObj == null) return;
 
            Resultado res = metodoObj.ejecutar();
            ultimoResultado = res;
 
            lblResultadoVal.setText(String.format("%.10f", res.getValorFinal()));
            lblMensaje.setText(res.getMensaje());
            lblFuncionTomada.setText("f(x) = " + funcion);
 
            if (res.isConvergio()) {
                actualizarChip(lblChipConvergio, "Convergió",
                    new Color(0x0F, 0x23, 0x18), VentanaPrincipal.GREEN_OK);
            } else {
                actualizarChip(lblChipConvergio, "No convergió",
                    new Color(0x2A, 0x10, 0x10), VentanaPrincipal.RED_ERR);
            }
            actualizarChip(lblChipIter,
                res.getIteraciones() + " iteraciones",
                VentanaPrincipal.BG_DEEP, VentanaPrincipal.TEXT_LABEL);
 
            persistencia.guardar(res);
 
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Revisá que todos los campos numéricos estén completos.",
                "Error de formato", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al ejecutar: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    // ------------------------------------------------------------------ //
    //  Graficar f(x) con JFreeChart
    // ------------------------------------------------------------------ //
 
    private void graficar(double xMin, double xMax) {
        String funcion = txtFuncion.getText().trim();
        if (funcion.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Ingresá f(x) antes de graficar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
 
        core.Evaluador ev = new core.Evaluador(funcion);
        if (!ev.esValida()) {
            JOptionPane.showMessageDialog(this,
                "La función ingresada no es válida.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
 
        XYSeries serieFuncion = new XYSeries("f(x)");
        int puntos = 400;
        double paso = (xMax - xMin) / puntos;
        for (int i = 0; i <= puntos; i++) {
            double x = xMin + i * paso;
            try {
                double y = ev.evaluar(x);
                if (!Double.isNaN(y) && !Double.isInfinite(y) && Math.abs(y) < 1e10)
                    serieFuncion.add(x, y);
            } catch (Exception ignored) {}
        }
 
        XYSeriesCollection dataset = new XYSeriesCollection(serieFuncion);
 
        if (ultimoResultado != null && ultimoResultado.isConvergio()) {
            XYSeries serieRaiz = new XYSeries("Raíz");
            double raiz = ultimoResultado.getValorFinal();
            try {
                serieRaiz.add(raiz, ev.evaluar(raiz));
                dataset.addSeries(serieRaiz);
            } catch (Exception ignored) {}
        }
 
        JFreeChart chart = ChartFactory.createXYLineChart(
            "", "x", "f(x)", dataset
        );
 
        chart.setBackgroundPaint(VentanaPrincipal.BG_PANEL);
        if (chart.getLegend() != null) {
            chart.getLegend().setBackgroundPaint(VentanaPrincipal.BG_PANEL);
            chart.getLegend().setItemPaint(VentanaPrincipal.TEXT_LABEL);
        }
 
        XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(VentanaPrincipal.BG_DEEP);
        plot.setDomainGridlinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.setRangeGridlinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.getDomainAxis().setTickLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getRangeAxis().setTickLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getDomainAxis().setLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getRangeAxis().setLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getDomainAxis().setAxisLinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.getRangeAxis().setAxisLinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.setRangeZeroBaselineVisible(true);
        plot.setRangeZeroBaselinePaint(VentanaPrincipal.TEXT_MUTED);
 
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesPaint(0, VentanaPrincipal.ACCENT_BLUE);
        renderer.setSeriesStroke(0, new BasicStroke(2.0f));
        renderer.setSeriesShapesVisible(0, false);
 
        if (dataset.getSeriesCount() > 1) {
            renderer.setSeriesPaint(1, new Color(0xE2, 0x4B, 0x4A));
            renderer.setSeriesLinesVisible(1, false);
            renderer.setSeriesShapesVisible(1, true);
            renderer.setSeriesShape(1, new Ellipse2D.Double(-6, -6, 12, 12));
        }
 
        plot.setRenderer(renderer);
        chartPanel.setChart(chart);
    }
 
    // ------------------------------------------------------------------ //
    //  Helpers de estilo
    // ------------------------------------------------------------------ //
 
    private JLabel crearLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lbl.setForeground(VentanaPrincipal.TEXT_LABEL);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }
 
    private JTextField crearInput(String placeholder) {
        JTextField field = new JTextField();
        field.setBackground(VentanaPrincipal.BG_INPUT);
        field.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        field.setCaretColor(VentanaPrincipal.ACCENT_BLUE);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(6, 10, 6, 10)
        ));
        field.setFont(new Font("Monospaced", Font.PLAIN, 13));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setToolTipText(placeholder);
        return field;
    }
 
    private JTextField crearInputPequeno(String valor) {
        JTextField field = crearInput(valor);
        field.setText(valor);
        field.setPreferredSize(new Dimension(70, 32));
        field.setMaximumSize(new Dimension(70, 32));
        return field;
    }
 
    private JButton crearBotonPrimario(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(VentanaPrincipal.ACCENT_DIM);
        btn.setForeground(VentanaPrincipal.ACCENT_LIGHT);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0x3D, 0x4F, 0x96), 1),
            new EmptyBorder(8, 20, 8, 20)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0x3D, 0x4F, 0x96));
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(VentanaPrincipal.ACCENT_DIM);
            }
        });
        return btn;
    }
 
    private JLabel crearChip(String texto, Color bg, Color fg) {
        JLabel chip = new JLabel(texto);
        chip.setFont(new Font("SansSerif", Font.PLAIN, 11));
        chip.setForeground(fg);
        chip.setBackground(bg);
        chip.setOpaque(true);
        chip.setBorder(new EmptyBorder(3, 8, 3, 8));
        return chip;
    }
 
    private void actualizarChip(JLabel chip, String texto, Color bg, Color fg) {
        chip.setText(texto);
        chip.setBackground(bg);
        chip.setForeground(fg);
    }
 
    private void estilizarCombo(JComboBox<?> combo) {
        combo.setBackground(VentanaPrincipal.BG_INPUT);
        combo.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        combo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        combo.setBorder(BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1));
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        combo.setAlignmentX(Component.LEFT_ALIGNMENT);
    }
 
    private void estilizarTabs(JTabbedPane tabs) {
        tabs.setBackground(VentanaPrincipal.BG_DEEP);
        tabs.setForeground(VentanaPrincipal.TEXT_LABEL);
        tabs.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabs.setBorder(null);
    }
 
    // ------------------------------------------------------------------ //
    //  Destructor
    // ------------------------------------------------------------------ //
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("PanelRaices destruido.");
        } finally {
            super.finalize();
        }
    }
}