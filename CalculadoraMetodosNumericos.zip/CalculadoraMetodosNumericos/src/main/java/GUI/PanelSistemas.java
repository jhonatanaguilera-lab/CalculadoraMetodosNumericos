package gui;
 
import core.Resultado;
import persistencia.Persistencia;
import sistemaslineales.*;
 
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
 
/**
 * Panel de Sistemas Lineales.
 * Grilla editable para ingresar la matriz A y el vector b.
 * Métodos: Gauss-Jordan, Jacobi, Gauss-Seidel.
 */
public class PanelSistemas extends JPanel {
 
    // ------------------------------------------------------------------ //
    //  Componentes
    // ------------------------------------------------------------------ //
 
    private JComboBox<String> comboMetodo;
    private JSpinner          spinnerSize;   // tamaño n del sistema
 
    // Grilla matriz A
    private JTable            tablaA;
    private DefaultTableModel modeloA;
 
    // Grilla vector b
    private JTable            tablaB;
    private DefaultTableModel modeloB;
 
    // Parámetros iterativos (Jacobi / Gauss-Seidel)
    private JPanel     panelIterativo;
    private JTable     tablaP0;
    private DefaultTableModel modeloP0;
    private JTextField txtTol;
    private JTextField txtM;
 
    // Parámetro Gauss-Jordan
    private JPanel     panelGauss;
    private JTextField txtDelta;
 
    // Resultado
    private JTextArea  areaResultado;
    private JLabel     lblChipEstado;
    private JLabel     lblChipIter;
 
    private int        tamano = 3;   // tamaño actual del sistema
    private final Persistencia persistencia = new Persistencia();
 
    // ------------------------------------------------------------------ //
    //  Constructor
    // ------------------------------------------------------------------ //
 
    public PanelSistemas() {
        setBackground(VentanaPrincipal.BG_DEEP);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20, 20, 20, 20));
        construirUI();
    }
 
    // ------------------------------------------------------------------ //
    //  Construcción de la UI
    // ------------------------------------------------------------------ //
 
    private void construirUI() {
        JLabel titulo = new JLabel("Sistemas lineales");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        titulo.setBorder(new EmptyBorder(0, 0, 16, 0));
        add(titulo, BorderLayout.NORTH);
 
        // Layout principal: izquierda (grillas) | derecha (resultado)
        JPanel cuerpo = new JPanel(new BorderLayout(16, 0));
        cuerpo.setBackground(VentanaPrincipal.BG_DEEP);
        add(cuerpo, BorderLayout.CENTER);
 
        cuerpo.add(construirPanelIzquierdo(), BorderLayout.WEST);
        cuerpo.add(construirPanelResultado(), BorderLayout.CENTER);
    }
 
    // ------------------------------------------------------------------ //
    //  Panel izquierdo — configuración y grillas
    // ------------------------------------------------------------------ //
 
    private JPanel construirPanelIzquierdo() {
        JPanel panel = new JPanel();
        panel.setBackground(VentanaPrincipal.BG_PANEL);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(16, 16, 16, 16)
        ));
        panel.setPreferredSize(new Dimension(460, 0));
 
        // --- Método ---
        panel.add(crearLabel("Método"));
        panel.add(Box.createVerticalStrut(4));
        comboMetodo = new JComboBox<>(new String[]{"Gauss-Jordan", "Jacobi", "Gauss-Seidel"});
        estilizarCombo(comboMetodo);
        panel.add(comboMetodo);
        panel.add(Box.createVerticalStrut(12));
 
        // --- Tamaño del sistema ---
        JPanel filaTamano = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filaTamano.setBackground(VentanaPrincipal.BG_PANEL);
        filaTamano.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lblTam = crearLabel("Tamaño del sistema (n × n):");
        filaTamano.add(lblTam);
        SpinnerNumberModel spinModel = new SpinnerNumberModel(3, 2, 8, 1);
        spinnerSize = new JSpinner(spinModel);
        estilizarSpinner(spinnerSize);
        filaTamano.add(spinnerSize);
        JButton btnAplicar = crearBotonSecundario("Aplicar");
        filaTamano.add(btnAplicar);
        panel.add(filaTamano);
        panel.add(Box.createVerticalStrut(14));
 
        // --- Grilla Matriz A ---
        panel.add(crearLabel("Matriz A"));
        panel.add(Box.createVerticalStrut(6));
        modeloA = new DefaultTableModel(tamano, tamano);
        tablaA  = crearTabla(modeloA);
        JScrollPane scrollA = new JScrollPane(tablaA);
        estilizarScroll(scrollA);
        scrollA.setAlignmentX(Component.LEFT_ALIGNMENT);
        scrollA.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
        scrollA.setPreferredSize(new Dimension(400, 100));
        panel.add(scrollA);
        panel.add(Box.createVerticalStrut(12));
 
        // --- Grilla Vector b ---
        panel.add(crearLabel("Vector b  —  términos independientes"));
        panel.add(Box.createVerticalStrut(6));
        modeloB = new DefaultTableModel(1, tamano);
        tablaB  = crearTabla(modeloB);
        JScrollPane scrollB = new JScrollPane(tablaB);
        estilizarScroll(scrollB);
        scrollB.setAlignmentX(Component.LEFT_ALIGNMENT);
        scrollB.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        scrollB.setPreferredSize(new Dimension(400, 42));
        panel.add(scrollB);
        panel.add(Box.createVerticalStrut(14));
 
        // --- Parámetros Gauss-Jordan ---
        panelGauss = new JPanel();
        panelGauss.setBackground(VentanaPrincipal.BG_PANEL);
        panelGauss.setLayout(new BoxLayout(panelGauss, BoxLayout.Y_AXIS));
        panelGauss.setAlignmentX(Component.LEFT_ALIGNMENT);
 
        panelGauss.add(crearLabel("delta  —  tolerancia para sistema singular"));
        panelGauss.add(Box.createVerticalStrut(4));
        txtDelta = crearInput("ej: 1e-10");
        txtDelta.setText("1e-10");
        panelGauss.add(txtDelta);
        panelGauss.add(Box.createVerticalStrut(12));
        panel.add(panelGauss);
 
        // --- Parámetros Jacobi / Gauss-Seidel ---
        panelIterativo = new JPanel();
        panelIterativo.setBackground(VentanaPrincipal.BG_PANEL);
        panelIterativo.setLayout(new BoxLayout(panelIterativo, BoxLayout.Y_AXIS));
        panelIterativo.setAlignmentX(Component.LEFT_ALIGNMENT);
 
        panelIterativo.add(crearLabel("Vector P₀  —  aproximación inicial"));
        panelIterativo.add(Box.createVerticalStrut(6));
        modeloP0 = new DefaultTableModel(1, tamano);
        tablaP0  = crearTabla(modeloP0);
        actualizarEncabezados();   // los tres modelos ya están creados
        JScrollPane scrollP0 = new JScrollPane(tablaP0);
        estilizarScroll(scrollP0);
        scrollP0.setAlignmentX(Component.LEFT_ALIGNMENT);
        scrollP0.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        scrollP0.setPreferredSize(new Dimension(400, 42));
        panelIterativo.add(scrollP0);
        panelIterativo.add(Box.createVerticalStrut(12));
 
        JPanel filaTolM = new JPanel(new GridLayout(1, 2, 10, 0));
        filaTolM.setBackground(VentanaPrincipal.BG_PANEL);
        filaTolM.setAlignmentX(Component.LEFT_ALIGNMENT);
        filaTolM.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
 
        JPanel colTol = new JPanel(new BorderLayout(0, 4));
        colTol.setBackground(VentanaPrincipal.BG_PANEL);
        colTol.add(crearLabel("Tolerancia"), BorderLayout.NORTH);
        txtTol = crearInput("ej: 1e-6");
        colTol.add(txtTol, BorderLayout.CENTER);
 
        JPanel colM = new JPanel(new BorderLayout(0, 4));
        colM.setBackground(VentanaPrincipal.BG_PANEL);
        colM.add(crearLabel("Máx. iteraciones"), BorderLayout.NORTH);
        txtM = crearInput("100");
        colM.add(txtM, BorderLayout.CENTER);
 
        filaTolM.add(colTol);
        filaTolM.add(colM);
        panelIterativo.add(filaTolM);
        panelIterativo.add(Box.createVerticalStrut(12));
        panel.add(panelIterativo);
 
        // Botón ejecutar
        JButton btnEjecutar = crearBotonPrimario("▶   Ejecutar");
        panel.add(btnEjecutar);
        panel.add(Box.createVerticalGlue());
 
        // Eventos
        btnAplicar.addActionListener(e -> {
            tamano = (int) spinnerSize.getValue();
            redimensionarGrillas();
        });
 
        comboMetodo.addActionListener(e -> actualizarPanelParams());
        actualizarPanelParams();
 
        btnEjecutar.addActionListener(e -> ejecutar());
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Actualizar panel de parámetros según método
    // ------------------------------------------------------------------ //
 
    private void actualizarPanelParams() {
        String metodo = (String) comboMetodo.getSelectedItem();
        boolean esGauss = "Gauss-Jordan".equals(metodo);
        panelGauss.setVisible(esGauss);
        panelIterativo.setVisible(!esGauss);
        panelGauss.revalidate();
        panelIterativo.revalidate();
    }
 
    // ------------------------------------------------------------------ //
    //  Redimensionar grillas al cambiar n
    // ------------------------------------------------------------------ //
 
    private void redimensionarGrillas() {
        // Matriz A
        modeloA.setColumnCount(tamano);
        modeloA.setRowCount(tamano);
 
        // Vector b
        modeloB.setColumnCount(tamano);
 
        // Vector P0
        modeloP0.setColumnCount(tamano);
 
        actualizarEncabezados();
 
        tablaA.revalidate();
        tablaB.revalidate();
        tablaP0.revalidate();
        repaint();
    }
 
    private void actualizarEncabezados() {
        String[] headers = new String[tamano];
        for (int i = 0; i < tamano; i++) headers[i] = "x" + (i + 1);
        modeloA.setColumnIdentifiers(headers);
        modeloB.setColumnIdentifiers(headers);
        modeloP0.setColumnIdentifiers(headers);
    }
 
    // ------------------------------------------------------------------ //
    //  Panel de resultado
    // ------------------------------------------------------------------ //
 
    private JPanel construirPanelResultado() {
        JPanel panel = new JPanel();
        panel.setBackground(VentanaPrincipal.BG_PANEL);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(16, 16, 16, 16)
        ));
 
        JLabel tit = crearLabel("Resultado");
        tit.setFont(new Font("SansSerif", Font.BOLD, 13));
        panel.add(tit);
        panel.add(Box.createVerticalStrut(12));
 
        // Chips de estado
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        chips.setBackground(VentanaPrincipal.BG_PANEL);
        chips.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblChipEstado = crearChip("—", VentanaPrincipal.BG_PANEL, VentanaPrincipal.TEXT_MUTED);
        lblChipIter   = crearChip("—", VentanaPrincipal.BG_PANEL, VentanaPrincipal.TEXT_MUTED);
        chips.add(lblChipEstado);
        chips.add(lblChipIter);
        panel.add(chips);
        panel.add(Box.createVerticalStrut(12));
 
        // Área de texto con el vector solución
        panel.add(crearLabel("Vector solución  X"));
        panel.add(Box.createVerticalStrut(6));
 
        areaResultado = new JTextArea(10, 20);
        areaResultado.setBackground(VentanaPrincipal.BG_DEEP);
        areaResultado.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        areaResultado.setFont(new Font("Monospaced", Font.PLAIN, 14));
        areaResultado.setBorder(new EmptyBorder(10, 12, 10, 12));
        areaResultado.setEditable(false);
        areaResultado.setCaretColor(VentanaPrincipal.ACCENT_BLUE);
        areaResultado.setText("Ejecutá el método para ver la solución.");
 
        JScrollPane scrollResultado = new JScrollPane(areaResultado);
        scrollResultado.setBorder(BorderFactory.createLineBorder(
            VentanaPrincipal.BORDER_COLOR, 1));
        scrollResultado.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(scrollResultado);
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Lógica de ejecución
    // ------------------------------------------------------------------ //
 
    private void ejecutar() {
        try {
            double[][] A = leerMatriz();
            double[]   b = leerVector(modeloB);
            String metodo = (String) comboMetodo.getSelectedItem();
 
            MetodoSistemas metodoObj = null;
 
            switch (metodo) {
                case "Gauss-Jordan" -> {
                    double delta = Double.parseDouble(txtDelta.getText().trim());
                    metodoObj = new GaussJordan(A, b, delta);
                }
                case "Jacobi" -> {
                    double[] P0 = leerVector(modeloP0);
                    double   tol = Double.parseDouble(txtTol.getText().trim());
                    int      m   = Integer.parseInt(txtM.getText().trim());
                    metodoObj = new GaussJacobi(A, b, P0, tol, m);
                }
                case "Gauss-Seidel" -> {
                    double[] P0 = leerVector(modeloP0);
                    double   tol = Double.parseDouble(txtTol.getText().trim());
                    int      m   = Integer.parseInt(txtM.getText().trim());
                    metodoObj = new GaussSeidel(A, b, P0, tol, m);
                }
            }
 
            if (metodoObj == null) return;
 
            Resultado res = metodoObj.ejecutar();
 
            // Mostrar vector solución formateado
            mostrarSolucion(res);
 
            if (res.isConvergio()) {
                actualizarChip(lblChipEstado, "Convergió",
                    new Color(0x0F, 0x23, 0x18), VentanaPrincipal.GREEN_OK);
            } else {
                actualizarChip(lblChipEstado, "No convergió",
                    new Color(0x2A, 0x10, 0x10), VentanaPrincipal.RED_ERR);
            }
 
            if (res.getIteraciones() > 0) {
                actualizarChip(lblChipIter,
                    res.getIteraciones() + " iteraciones",
                    VentanaPrincipal.BG_DEEP, VentanaPrincipal.TEXT_LABEL);
            } else {
                lblChipIter.setText("—");
            }
 
            persistencia.guardar(res);
 
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Revisá que todos los campos de la matriz estén completos y sean numéricos.",
                "Error de formato", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al ejecutar: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    // ------------------------------------------------------------------ //
    //  Mostrar solución formateada en el área de texto
    // ------------------------------------------------------------------ //
 
    private void mostrarSolucion(Resultado res) {
        if (!res.isConvergio()) {
            areaResultado.setText(res.getMensaje());
            return;
        }
 
        // Parsear el mensaje que contiene "Solución: [x1=..., x2=..., ...]"
        String msg = res.getMensaje();
        StringBuilder sb = new StringBuilder();
 
        if (msg.contains("Solución: [")) {
            String contenido = msg.replace("Solución: [", "").replace("]", "");
            String[] partes  = contenido.split(", ");
            for (String parte : partes) {
                sb.append(parte.trim()).append("\n");
            }
        } else {
            sb.append(msg);
        }
 
        areaResultado.setText(sb.toString());
    }
 
    // ------------------------------------------------------------------ //
    //  Leer datos de las grillas
    // ------------------------------------------------------------------ //
 
    private double[][] leerMatriz() throws NumberFormatException {
        double[][] A = new double[tamano][tamano];
        for (int i = 0; i < tamano; i++) {
            for (int j = 0; j < tamano; j++) {
                Object val = modeloA.getValueAt(i, j);
                if (val == null || val.toString().trim().isEmpty())
                    throw new NumberFormatException("Celda A[" + (i+1) + "][" + (j+1) + "] vacía.");
                A[i][j] = Double.parseDouble(val.toString().trim());
            }
        }
        return A;
    }
 
    private double[] leerVector(DefaultTableModel modelo) throws NumberFormatException {
        double[] v = new double[tamano];
        for (int j = 0; j < tamano; j++) {
            Object val = modelo.getValueAt(0, j);
            if (val == null || val.toString().trim().isEmpty())
                throw new NumberFormatException("Celda vacía en el vector.");
            v[j] = Double.parseDouble(val.toString().trim());
        }
        return v;
    }
 
    // ------------------------------------------------------------------ //
    //  Helpers de estilo
    // ------------------------------------------------------------------ //
 
    private JTable crearTabla(DefaultTableModel modelo) {
        JTable tabla = new JTable(modelo);
        tabla.setBackground(VentanaPrincipal.BG_INPUT);
        tabla.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        tabla.setFont(new Font("Monospaced", Font.PLAIN, 13));
        tabla.setRowHeight(28);
        tabla.setGridColor(VentanaPrincipal.BORDER_COLOR);
        tabla.setSelectionBackground(VentanaPrincipal.BG_HOVER);
        tabla.setSelectionForeground(VentanaPrincipal.ACCENT_BLUE);
        tabla.setBorder(null);
        tabla.setShowGrid(true);
 
        // Encabezado de la tabla
        JTableHeader header = tabla.getTableHeader();
        header.setBackground(VentanaPrincipal.BG_PANEL);
        header.setForeground(VentanaPrincipal.TEXT_LABEL);
        header.setFont(new Font("SansSerif", Font.PLAIN, 11));
        header.setBorder(BorderFactory.createMatteBorder(
            0, 0, 1, 0, VentanaPrincipal.BORDER_COLOR));
 
        // Centrar el contenido de las celdas
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        centerRenderer.setBackground(VentanaPrincipal.BG_INPUT);
        centerRenderer.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        tabla.setDefaultRenderer(Object.class, centerRenderer);
 
        return tabla;
    }
 
    private void estilizarScroll(JScrollPane scroll) {
        scroll.setBorder(BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1));
        scroll.getViewport().setBackground(VentanaPrincipal.BG_INPUT);
        scroll.setBackground(VentanaPrincipal.BG_PANEL);
    }
 
    private void estilizarCombo(JComboBox<?> combo) {
        combo.setBackground(VentanaPrincipal.BG_INPUT);
        combo.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        combo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        combo.setBorder(BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1));
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        combo.setAlignmentX(Component.LEFT_ALIGNMENT);
    }
 
    private void estilizarSpinner(JSpinner spinner) {
        spinner.setBackground(VentanaPrincipal.BG_INPUT);
        spinner.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        spinner.setFont(new Font("Monospaced", Font.PLAIN, 13));
        spinner.setPreferredSize(new Dimension(60, 30));
        JFormattedTextField tf = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
        tf.setBackground(VentanaPrincipal.BG_INPUT);
        tf.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        tf.setCaretColor(VentanaPrincipal.ACCENT_BLUE);
    }
 
    private JLabel crearLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lbl.setForeground(VentanaPrincipal.TEXT_LABEL);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }
 
    private JTextField crearInput(String placeholder) {
        JTextField field = new JTextField();
        field.setBackground(VentanaPrincipal.BG_INPUT);
        field.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        field.setCaretColor(VentanaPrincipal.ACCENT_BLUE);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(6, 10, 6, 10)
        ));
        field.setFont(new Font("Monospaced", Font.PLAIN, 13));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setToolTipText(placeholder);
        return field;
    }
 
    private JButton crearBotonPrimario(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(VentanaPrincipal.ACCENT_DIM);
        btn.setForeground(VentanaPrincipal.ACCENT_LIGHT);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0x3D, 0x4F, 0x96), 1),
            new EmptyBorder(8, 20, 8, 20)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0x3D, 0x4F, 0x96));
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(VentanaPrincipal.ACCENT_DIM);
            }
        });
        return btn;
    }
 
    private JButton crearBotonSecundario(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(VentanaPrincipal.BG_HOVER);
        btn.setForeground(VentanaPrincipal.TEXT_LABEL);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(4, 12, 4, 12)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        return btn;
    }
 
    private JLabel crearChip(String texto, Color bg, Color fg) {
        JLabel chip = new JLabel(texto);
        chip.setFont(new Font("SansSerif", Font.PLAIN, 11));
        chip.setForeground(fg);
        chip.setBackground(bg);
        chip.setOpaque(true);
        chip.setBorder(new EmptyBorder(3, 8, 3, 8));
        return chip;
    }
 
    private void actualizarChip(JLabel chip, String texto, Color bg, Color fg) {
        chip.setText(texto);
        chip.setBackground(bg);
        chip.setForeground(fg);
    }
 
    // ------------------------------------------------------------------ //
    //  Destructor
    // ------------------------------------------------------------------ //
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("PanelSistemas destruido.");
        } finally {
            super.finalize();
        }
    }
}