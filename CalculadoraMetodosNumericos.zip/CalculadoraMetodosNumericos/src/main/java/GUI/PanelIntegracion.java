package gui;
 
import core.Resultado;
import integracion.*;
import persistencia.Persistencia;
 
import org.jfree.chart.*;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.*;
import org.jfree.data.xy.*;
 
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.io.File;
 
/**
 * Panel de Integración Numérica.
 * Pestaña "Calcular": formulario + resultado.
 * Pestaña "Gráfica": curva de f(x) con área sombreada.
 */
public class PanelIntegracion extends JPanel {
 
    // ------------------------------------------------------------------ //
    //  Componentes del formulario
    // ------------------------------------------------------------------ //
 
    private JComboBox<String> comboMetodo;
    private JComboBox<String> comboModo;       // Función / Tabulado
 
    // Modo función
    private JPanel   panelFuncion;
    private JTextField txtFuncion;
    private JTextField txtA;
    private JTextField txtB;
    private JTextField txtN;
 
    // Modo tabulado
    private JPanel   panelTabulado;
    private JLabel   lblArchivoTabulado;
    private double[] tabX;
    private double[] tabFy;
 
    // Resultado
    private JLabel lblResultadoVal;
    private JLabel lblFuncionTomada;
    private JLabel lblMensaje;
    private JLabel lblChipEstado;
 
    // Gráfica
    private ChartPanel chartPanel;
    private Resultado  ultimoResultado;
 
    private final Persistencia persistencia = new Persistencia();
 
    // ------------------------------------------------------------------ //
    //  Constructor
    // ------------------------------------------------------------------ //
 
    public PanelIntegracion() {
        setBackground(VentanaPrincipal.BG_DEEP);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20, 20, 20, 20));
        construirUI();
    }
 
    // ------------------------------------------------------------------ //
    //  Construcción de la UI
    // ------------------------------------------------------------------ //
 
    private void construirUI() {
        JLabel titulo = new JLabel("Integración numérica");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        titulo.setBorder(new EmptyBorder(0, 0, 16, 0));
        add(titulo, BorderLayout.NORTH);
 
        JTabbedPane tabs = new JTabbedPane();
        estilizarTabs(tabs);
        tabs.addTab("  Calcular  ", construirPestanaCalcular());
        tabs.addTab("  Gráfica   ", construirPestanaGrafica());
        add(tabs, BorderLayout.CENTER);
    }
 
    // ------------------------------------------------------------------ //
    //  Pestaña Calcular
    // ------------------------------------------------------------------ //
 
    private JPanel construirPestanaCalcular() {
        JPanel panel = new JPanel(new BorderLayout(16, 0));
        panel.setBackground(VentanaPrincipal.BG_DEEP);
        panel.setBorder(new EmptyBorder(16, 0, 0, 0));
 
        // --- Formulario ---
        JPanel formulario = new JPanel();
        formulario.setBackground(VentanaPrincipal.BG_PANEL);
        formulario.setLayout(new BoxLayout(formulario, BoxLayout.Y_AXIS));
        formulario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(16, 16, 16, 16)
        ));
 
        // Método
        formulario.add(crearLabel("Método"));
        formulario.add(Box.createVerticalStrut(4));
        comboMetodo = new JComboBox<>(new String[]{"Trapecio", "Simpson 1/3", "Simpson 3/8"});
        estilizarCombo(comboMetodo);
        formulario.add(comboMetodo);
        formulario.add(Box.createVerticalStrut(12));
 
        // Modo: Función / Tabulado
        formulario.add(crearLabel("Modo de ingreso"));
        formulario.add(Box.createVerticalStrut(4));
        comboModo = new JComboBox<>(new String[]{"Función", "Datos tabulados (.txt)"});
        estilizarCombo(comboModo);
        formulario.add(comboModo);
        formulario.add(Box.createVerticalStrut(12));
 
        // Panel modo función
        panelFuncion = new JPanel();
        panelFuncion.setBackground(VentanaPrincipal.BG_PANEL);
        panelFuncion.setLayout(new BoxLayout(panelFuncion, BoxLayout.Y_AXIS));
 
        panelFuncion.add(crearLabel("f(x)"));
        panelFuncion.add(Box.createVerticalStrut(4));
        txtFuncion = crearInput("ej: x^2 + 1");
        panelFuncion.add(txtFuncion);
        panelFuncion.add(Box.createVerticalStrut(12));
 
        JPanel filaABN = new JPanel(new GridLayout(1, 3, 10, 0));
        filaABN.setBackground(VentanaPrincipal.BG_PANEL);
        filaABN.setAlignmentX(Component.LEFT_ALIGNMENT);
 
        JPanel colA = new JPanel(new BorderLayout(0, 4));
        colA.setBackground(VentanaPrincipal.BG_PANEL);
        colA.add(crearLabel("a  —  límite inferior"), BorderLayout.NORTH);
        txtA = crearInput("ej: 0");
        colA.add(txtA, BorderLayout.CENTER);
 
        JPanel colB = new JPanel(new BorderLayout(0, 4));
        colB.setBackground(VentanaPrincipal.BG_PANEL);
        colB.add(crearLabel("b  —  límite superior"), BorderLayout.NORTH);
        txtB = crearInput("ej: 1");
        colB.add(txtB, BorderLayout.CENTER);
 
        JPanel colN = new JPanel(new BorderLayout(0, 4));
        colN.setBackground(VentanaPrincipal.BG_PANEL);
        colN.add(crearLabel("n  —  subintervalos"), BorderLayout.NORTH);
        txtN = crearInput("ej: 4");
        colN.add(txtN, BorderLayout.CENTER);
 
        filaABN.add(colA);
        filaABN.add(colB);
        filaABN.add(colN);
        panelFuncion.add(filaABN);
        panelFuncion.add(Box.createVerticalStrut(12));
 
        // Panel modo tabulado
        panelTabulado = new JPanel();
        panelTabulado.setBackground(VentanaPrincipal.BG_PANEL);
        panelTabulado.setLayout(new BoxLayout(panelTabulado, BoxLayout.Y_AXIS));
 
        JButton btnCargar = crearBotonPrimario("Cargar archivo .txt");
        btnCargar.setAlignmentX(Component.LEFT_ALIGNMENT);
        panelTabulado.add(btnCargar);
        panelTabulado.add(Box.createVerticalStrut(8));
 
        lblArchivoTabulado = new JLabel("Ningún archivo cargado");
        lblArchivoTabulado.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblArchivoTabulado.setForeground(VentanaPrincipal.TEXT_MUTED);
        lblArchivoTabulado.setAlignmentX(Component.LEFT_ALIGNMENT);
        panelTabulado.add(lblArchivoTabulado);
        panelTabulado.add(Box.createVerticalStrut(12));
 
        btnCargar.addActionListener(e -> cargarArchivoDatos());
 
        formulario.add(panelFuncion);
        formulario.add(panelTabulado);
 
        // Botón ejecutar
        JButton btnEjecutar = crearBotonPrimario("▶   Ejecutar");
        formulario.add(btnEjecutar);
        formulario.add(Box.createVerticalGlue());
 
        // Alternar paneles según modo
        comboModo.addActionListener(e -> actualizarModo());
        actualizarModo();
 
        btnEjecutar.addActionListener(e -> ejecutar());
 
        panel.add(formulario, BorderLayout.WEST);
        panel.add(construirPanelResultado(), BorderLayout.CENTER);
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Alternar modo función / tabulado
    // ------------------------------------------------------------------ //
 
    private void actualizarModo() {
        boolean esFuncion = comboModo.getSelectedIndex() == 0;
        panelFuncion.setVisible(esFuncion);
        panelTabulado.setVisible(!esFuncion);
        panelFuncion.revalidate();
        panelTabulado.revalidate();
    }
 
    // ------------------------------------------------------------------ //
    //  Cargar archivo de datos tabulados
    // ------------------------------------------------------------------ //
 
    private void cargarArchivoDatos() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Archivos de texto (*.txt)", "txt"));
        fc.setDialogTitle("Seleccionar archivo de datos tabulados");
 
        int resultado = fc.showOpenDialog(this);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = fc.getSelectedFile();
            double[][] datos = persistencia.leerDatosTabulados(archivo.getAbsolutePath());
            if (datos != null) {
                tabX  = datos[0];
                tabFy = datos[1];
                lblArchivoTabulado.setText(archivo.getName()
                    + "  —  " + tabX.length + " puntos cargados");
                lblArchivoTabulado.setForeground(VentanaPrincipal.GREEN_OK);
            } else {
                lblArchivoTabulado.setText("Error al leer el archivo. Revisá el formato.");
                lblArchivoTabulado.setForeground(VentanaPrincipal.RED_ERR);
                tabX  = null;
                tabFy = null;
            }
        }
    }
 
    // ------------------------------------------------------------------ //
    //  Panel de resultado
    // ------------------------------------------------------------------ //
 
    private JPanel construirPanelResultado() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBackground(VentanaPrincipal.BG_PANEL);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(16, 16, 16, 16)
        ));
 
        // --- Parte superior: resultado ---
        JPanel panelRes = new JPanel();
        panelRes.setBackground(VentanaPrincipal.BG_PANEL);
        panelRes.setLayout(new BoxLayout(panelRes, BoxLayout.Y_AXIS));
 
        JLabel tit = crearLabel("Resultado");
        tit.setFont(new Font("SansSerif", Font.BOLD, 13));
        panelRes.add(tit);
        panelRes.add(Box.createVerticalStrut(12));
 
        panelRes.add(crearLabel("Integral aproximada"));
        panelRes.add(Box.createVerticalStrut(6));
 
        lblResultadoVal = new JLabel("—");
        lblResultadoVal.setFont(new Font("Monospaced", Font.BOLD, 22));
        lblResultadoVal.setForeground(VentanaPrincipal.ACCENT_BLUE);
        panelRes.add(lblResultadoVal);
        panelRes.add(Box.createVerticalStrut(12));
 
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        chips.setBackground(VentanaPrincipal.BG_PANEL);
        lblChipEstado = crearChip("—", VentanaPrincipal.BG_PANEL, VentanaPrincipal.TEXT_MUTED);
        chips.add(lblChipEstado);
        panelRes.add(chips);
        panelRes.add(Box.createVerticalStrut(8));
 
        lblMensaje = new JLabel(" ");
        lblMensaje.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblMensaje.setForeground(VentanaPrincipal.TEXT_LABEL);
        panelRes.add(lblMensaje);
        panelRes.add(Box.createVerticalStrut(10));
 
        panelRes.add(crearLabel("Función evaluada"));
        panelRes.add(Box.createVerticalStrut(4));
        lblFuncionTomada = new JLabel("—");
        lblFuncionTomada.setFont(new Font("Monospaced", Font.PLAIN, 13));
        lblFuncionTomada.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        panelRes.add(lblFuncionTomada);
 
        panel.add(panelRes, BorderLayout.NORTH);
 
        // --- Parte inferior: guía de sintaxis ---
        panel.add(construirGuiaSintaxis(), BorderLayout.CENTER);
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Guía de sintaxis — idéntica a PanelRaices
    // ------------------------------------------------------------------ //
 
    private JPanel construirGuiaSintaxis() {
        JPanel panel = new JPanel();
        panel.setBackground(VentanaPrincipal.BG_DEEP);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(14, 14, 14, 14)
        ));
 
        JLabel titGuia = new JLabel("Guía de sintaxis  —  cómo escribir f(x)");
        titGuia.setFont(new Font("SansSerif", Font.BOLD, 12));
        titGuia.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        titGuia.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(titGuia);
        panel.add(Box.createVerticalStrut(12));
 
        String[][] operadores = {
            { "+  /  -",    "Suma, división, resta",         "x^2 + 3*x - 1"      },
            { "*",          "Multiplicación",                 "2*x  o  2*(x+1)"    },
            { "^",          "Potencia",                       "x^3  o  x^0.5"      },
            { "sqrt(x)",    "Raíz cuadrada",                  "sqrt(x^2 - 4)"      },
            { "sin(x)",     "Seno  (radianes)",               "sin(x) - 0.5"       },
            { "cos(x)",     "Coseno  (radianes)",             "cos(x) + x"         },
            { "tan(x)",     "Tangente  (radianes)",           "tan(x) - 1"         },
            { "exp(x)",     "Número e elevado a x",           "exp(x) - 3"         },
            { "log(x)",     "Logaritmo natural  ln(x)",       "log(x) - 1"         },
            { "log10(x)",   "Logaritmo base 10",              "log10(x) - 2"       },
            { "abs(x)",     "Valor absoluto",                 "abs(x - 2) - 1"     },
            { "pi",         "Constante π ≈ 3.14159",          "sin(pi*x)"          },
            { "e",          "Constante e ≈ 2.71828",          "e^x  o  exp(1)*x"   },
        };
 
        for (String[] fila : operadores) {
            panel.add(crearFilaGuia(fila[0], fila[1], fila[2]));
            panel.add(Box.createVerticalStrut(5));
        }
 
        panel.add(Box.createVerticalStrut(8));
 
        JLabel nota1 = new JLabel(
            "⚠  Siempre escribí el operador *  entre número y variable:  2*x  no  2x");
        nota1.setFont(new Font("SansSerif", Font.ITALIC, 11));
        nota1.setForeground(new Color(0xE2, 0xA0, 0x2A));
        nota1.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(nota1);
        panel.add(Box.createVerticalStrut(4));
 
        JLabel nota2 = new JLabel(
            "⚠  Los ángulos de sin, cos y tan deben estar en radianes,  no en grados");
        nota2.setFont(new Font("SansSerif", Font.ITALIC, 11));
        nota2.setForeground(new Color(0xE2, 0xA0, 0x2A));
        nota2.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(nota2);
 
        return panel;
    }
 
    private JPanel crearFilaGuia(String sintaxis, String descripcion, String ejemplo) {
        JPanel fila = new JPanel(new GridLayout(1, 3, 10, 0));
        fila.setBackground(VentanaPrincipal.BG_DEEP);
        fila.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        fila.setAlignmentX(Component.LEFT_ALIGNMENT);
 
        JLabel lblSintaxis = new JLabel(sintaxis);
        lblSintaxis.setFont(new Font("Monospaced", Font.BOLD, 12));
        lblSintaxis.setForeground(VentanaPrincipal.ACCENT_BLUE);
 
        JLabel lblDesc = new JLabel(descripcion);
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblDesc.setForeground(VentanaPrincipal.TEXT_LABEL);
 
        JLabel lblEj = new JLabel(ejemplo);
        lblEj.setFont(new Font("Monospaced", Font.PLAIN, 11));
        lblEj.setForeground(VentanaPrincipal.TEXT_MUTED);
 
        fila.add(lblSintaxis);
        fila.add(lblDesc);
        fila.add(lblEj);
 
        return fila;
    }
 
    // ------------------------------------------------------------------ //
    //  Pestaña Gráfica
    // ------------------------------------------------------------------ //
 
    private JPanel construirPestanaGrafica() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(VentanaPrincipal.BG_DEEP);
        panel.setBorder(new EmptyBorder(16, 0, 0, 0));
 
        JPanel controles = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        controles.setBackground(VentanaPrincipal.BG_DEEP);
        controles.add(crearLabel("x min:"));
        JTextField txtXMin = crearInputPequeno("-1");
        controles.add(txtXMin);
        controles.add(crearLabel("x max:"));
        JTextField txtXMax = crearInputPequeno("5");
        controles.add(txtXMax);
        JButton btnGraficar = crearBotonPrimario("Graficar");
        controles.add(btnGraficar);
        panel.add(controles, BorderLayout.NORTH);
 
        chartPanel = new ChartPanel(null);
        chartPanel.setBackground(VentanaPrincipal.BG_PANEL);
        chartPanel.setBorder(BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1));
        panel.add(chartPanel, BorderLayout.CENTER);
 
        btnGraficar.addActionListener(e -> {
            try {
                double xMin = Double.parseDouble(txtXMin.getText().trim());
                double xMax = Double.parseDouble(txtXMax.getText().trim());
                graficar(xMin, xMax);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                    "Ingresá valores numéricos válidos para el rango.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
 
        return panel;
    }
 
    // ------------------------------------------------------------------ //
    //  Lógica de ejecución
    // ------------------------------------------------------------------ //
 
    private void ejecutar() {
        try {
            String metodo = (String) comboMetodo.getSelectedItem();
            boolean esFuncion = comboModo.getSelectedIndex() == 0;
            MetodoIntegracion metodoObj = null;
 
            if (esFuncion) {
                String funcion = txtFuncion.getText().trim();
                double a = Double.parseDouble(txtA.getText().trim());
                double b = Double.parseDouble(txtB.getText().trim());
                int    n = Integer.parseInt(txtN.getText().trim());
 
                if (funcion.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Ingresá f(x).",
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
 
                metodoObj = switch (metodo) {
                    case "Trapecio"    -> new Trapecio(funcion, a, b, n);
                    case "Simpson 1/3" -> new Simpson13(funcion, a, b, n);
                    case "Simpson 3/8" -> new Simpson38(funcion, a, b, n);
                    default -> null;
                };
            } else {
                if (tabX == null || tabFy == null) {
                    JOptionPane.showMessageDialog(this,
                        "Cargá un archivo de datos tabulados primero.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                metodoObj = switch (metodo) {
                    case "Trapecio"    -> new Trapecio(tabX, tabFy);
                    case "Simpson 1/3" -> new Simpson13(tabX, tabFy);
                    case "Simpson 3/8" -> new Simpson38(tabX, tabFy);
                    default -> null;
                };
            }
 
            if (metodoObj == null) return;
 
            Resultado res = metodoObj.ejecutar();
            ultimoResultado = res;
 
            lblResultadoVal.setText(String.format("%.10f", res.getValorFinal()));
            lblMensaje.setText(res.getMensaje());
            if (esFuncion) {
                lblFuncionTomada.setText("f(x) = " + txtFuncion.getText().trim());
            } else {
                lblFuncionTomada.setText("Datos tabulados  —  " + tabX.length + " puntos");
            }
 
            if (res.isConvergio()) {
                actualizarChip(lblChipEstado, "Cálculo exitoso",
                    new Color(0x0F, 0x23, 0x18), VentanaPrincipal.GREEN_OK);
            } else {
                actualizarChip(lblChipEstado, res.getMensaje(),
                    new Color(0x2A, 0x10, 0x10), VentanaPrincipal.RED_ERR);
            }
 
            persistencia.guardar(res);
 
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Revisá que todos los campos numéricos estén completos.",
                "Error de formato", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al ejecutar: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    // ------------------------------------------------------------------ //
    //  Graficar f(x) con área sombreada entre a y b
    // ------------------------------------------------------------------ //
 
    private void graficar(double xMin, double xMax) {
        boolean esFuncion = comboModo.getSelectedIndex() == 0;
 
        if (esFuncion) {
            String funcion = txtFuncion.getText().trim();
            if (funcion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresá f(x) antes de graficar.",
                    "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }
 
            core.Evaluador ev = new core.Evaluador(funcion);
            if (!ev.esValida()) {
                JOptionPane.showMessageDialog(this, "La función ingresada no es válida.",
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
 
            // Serie de la función completa
            XYSeries serieFuncion = new XYSeries("f(x)");
            int puntos = 400;
            double paso = (xMax - xMin) / puntos;
            for (int i = 0; i <= puntos; i++) {
                double x = xMin + i * paso;
                try {
                    double y = ev.evaluar(x);
                    if (!Double.isNaN(y) && !Double.isInfinite(y) && Math.abs(y) < 1e10)
                        serieFuncion.add(x, y);
                } catch (Exception ignored) {}
            }
 
            // Serie del área sombreada (si hay a y b definidos)
            XYSeries serieArea = new XYSeries("Área integrada");
            try {
                double a = Double.parseDouble(txtA.getText().trim());
                double b = Double.parseDouble(txtB.getText().trim());
                int    n = Math.max(200, Integer.parseInt(txtN.getText().trim()) * 10);
                double h = (b - a) / n;
                serieArea.add(a, 0.0);
                for (int i = 0; i <= n; i++) {
                    double x = a + i * h;
                    try { serieArea.add(x, ev.evaluar(x)); } catch (Exception ignored) {}
                }
                serieArea.add(b, 0.0);
            } catch (NumberFormatException ignored) {}
 
            XYSeriesCollection dataset = new XYSeriesCollection();
            dataset.addSeries(serieFuncion);
            dataset.addSeries(serieArea);
 
            JFreeChart chart = ChartFactory.createXYAreaChart(
                "", "x", "f(x)", dataset
            );
            aplicarTemaChart(chart);
 
            XYPlot plot = chart.getXYPlot();
            XYAreaRenderer renderer = new XYAreaRenderer();
            renderer.setSeriesPaint(0, new Color(VentanaPrincipal.ACCENT_BLUE.getRed(),
                VentanaPrincipal.ACCENT_BLUE.getGreen(),
                VentanaPrincipal.ACCENT_BLUE.getBlue(), 40));
            renderer.setSeriesPaint(1, new Color(VentanaPrincipal.ACCENT_BLUE.getRed(),
                VentanaPrincipal.ACCENT_BLUE.getGreen(),
                VentanaPrincipal.ACCENT_BLUE.getBlue(), 90));
            plot.setRenderer(renderer);
 
            chartPanel.setChart(chart);
 
        } else {
            // Modo tabulado — graficar los puntos directamente
            if (tabX == null) {
                JOptionPane.showMessageDialog(this, "Cargá los datos tabulados primero.",
                    "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }
 
            XYSeries serie = new XYSeries("Datos tabulados");
            for (int i = 0; i < tabX.length; i++) serie.add(tabX[i], tabFy[i]);
 
            XYSeriesCollection dataset = new XYSeriesCollection(serie);
            JFreeChart chart = ChartFactory.createXYLineChart(
                "", "x", "f(x)", dataset
            );
            aplicarTemaChart(chart);
 
            XYPlot plot = chart.getXYPlot();
            XYLineAndShapeRenderer r = new XYLineAndShapeRenderer();
            r.setSeriesPaint(0, VentanaPrincipal.ACCENT_BLUE);
            r.setSeriesStroke(0, new BasicStroke(2.0f));
            r.setSeriesShape(0, new Ellipse2D.Double(-4, -4, 8, 8));
            plot.setRenderer(r);
 
            chartPanel.setChart(chart);
        }
    }
 
    // ------------------------------------------------------------------ //
    //  Aplicar tema dark al chart
    // ------------------------------------------------------------------ //
 
    private void aplicarTemaChart(JFreeChart chart) {
        chart.setBackgroundPaint(VentanaPrincipal.BG_PANEL);
        if (chart.getLegend() != null) {
            chart.getLegend().setBackgroundPaint(VentanaPrincipal.BG_PANEL);
            chart.getLegend().setItemPaint(VentanaPrincipal.TEXT_LABEL);
        }
        XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(VentanaPrincipal.BG_DEEP);
        plot.setDomainGridlinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.setRangeGridlinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.getDomainAxis().setTickLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getRangeAxis().setTickLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getDomainAxis().setLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getRangeAxis().setLabelPaint(VentanaPrincipal.TEXT_LABEL);
        plot.getDomainAxis().setAxisLinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.getRangeAxis().setAxisLinePaint(VentanaPrincipal.BORDER_COLOR);
        plot.setRangeZeroBaselineVisible(true);
        plot.setRangeZeroBaselinePaint(VentanaPrincipal.TEXT_MUTED);
    }
 
    // ------------------------------------------------------------------ //
    //  Helpers de estilo
    // ------------------------------------------------------------------ //
 
    private JLabel crearLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lbl.setForeground(VentanaPrincipal.TEXT_LABEL);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }
 
    private JTextField crearInput(String placeholder) {
        JTextField field = new JTextField();
        field.setBackground(VentanaPrincipal.BG_INPUT);
        field.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        field.setCaretColor(VentanaPrincipal.ACCENT_BLUE);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1),
            new EmptyBorder(6, 10, 6, 10)
        ));
        field.setFont(new Font("Monospaced", Font.PLAIN, 13));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setToolTipText(placeholder);
        return field;
    }
 
    private JTextField crearInputPequeno(String valor) {
        JTextField f = crearInput(valor);
        f.setText(valor);
        f.setPreferredSize(new Dimension(70, 32));
        f.setMaximumSize(new Dimension(70, 32));
        return f;
    }
 
    private JButton crearBotonPrimario(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(VentanaPrincipal.ACCENT_DIM);
        btn.setForeground(VentanaPrincipal.ACCENT_LIGHT);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0x3D, 0x4F, 0x96), 1),
            new EmptyBorder(8, 20, 8, 20)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0x3D, 0x4F, 0x96));
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(VentanaPrincipal.ACCENT_DIM);
            }
        });
        return btn;
    }
 
    private JLabel crearChip(String texto, Color bg, Color fg) {
        JLabel chip = new JLabel(texto);
        chip.setFont(new Font("SansSerif", Font.PLAIN, 11));
        chip.setForeground(fg);
        chip.setBackground(bg);
        chip.setOpaque(true);
        chip.setBorder(new EmptyBorder(3, 8, 3, 8));
        return chip;
    }
 
    private void actualizarChip(JLabel chip, String texto, Color bg, Color fg) {
        chip.setText(texto);
        chip.setBackground(bg);
        chip.setForeground(fg);
    }
 
    private void estilizarCombo(JComboBox<?> combo) {
        combo.setBackground(VentanaPrincipal.BG_INPUT);
        combo.setForeground(VentanaPrincipal.TEXT_PRIMARY);
        combo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        combo.setBorder(BorderFactory.createLineBorder(VentanaPrincipal.BORDER_COLOR, 1));
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        combo.setAlignmentX(Component.LEFT_ALIGNMENT);
    }
 
    private void estilizarTabs(JTabbedPane tabs) {
        tabs.setBackground(VentanaPrincipal.BG_DEEP);
        tabs.setForeground(VentanaPrincipal.TEXT_LABEL);
        tabs.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabs.setBorder(null);
    }
 
    // ------------------------------------------------------------------ //
    //  Destructor
    // ------------------------------------------------------------------ //
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("PanelIntegracion destruido.");
        } finally {
            super.finalize();
        }
    }
}