package sistemaslineales;
import core.Resultado; 
/**
 * Método iterativo de Jacobi — RUTINA002.
 * Actualiza todas las incógnitas usando los valores del paso anterior (vector P).
 */
public class GaussJacobi extends MetodoSistemas {
 
    private double[] P;    // vector de aproximación inicial
    private double   tol;
    private int      m;    // máximo de iteraciones, default 100
 
    //  Constructor
 
    public GaussJacobi(double[][] A, double[] b, double[] P, double tol, int m) {
        super("Jacobi","Método iterativo que usa los valores del paso anterior.",A, b);
        this.P   = P.clone();
        this.tol = tol;
        this.m   = m;
    }
 
    //  Getters
 
    public double[] getP(){
        return P;
    }
 
    public double getTol(){
        return tol;
    }
 
    public int  getM(){
        return m;
    }

    // Setters
    public void setP(double[] P){
        this.P = P.clone();
    }    
    
    public void setTol(double t){
        this.tol = t;
    }
    
    public void setM(int m){
        this.m = m;
    }
    
    //  Utilidades — equivalentes a np.linalg.norm y np.delete 

    private double norma(double[] v) {
        double s = 0;
        for (double vi : v) s += vi * vi;
        return Math.sqrt(s);
    }
 
    // Producto punto de una fila de A (sin el índice skip) con X (sin el índice skip)
    // Equivalente a: A[j, np.delete(np.arange(n), j)].dot(X[np.delete(np.arange(n), j)])
    private double productoPunto(double[] fila, double[] vec, int skip) {
        double s = 0;
        for (int k = 0; k < fila.length; k++)
            if (k != skip) s += fila[k] * vec[k];
        return s;
    }
 
    //  Algoritmo — traducción directa de RUTINA002
 
    @Override
    public Resultado ejecutar() {
        int n = A.length;
        double[] Pi = P.clone();
        double[] X = new double[n];
        int iter = 0;
        boolean convergio = false;
        for (int i = 0; i < m; i++) {
            iter++;
            // Actualizar todas las incógnitas con valores del paso anterior (Pi)
            for (int j = 0; j < n; j++) {
                X[j] = (b[j] - productoPunto(A[j], Pi, j)) / A[j][j];
            }
            // Calcular error
            double[] diff = new double[n];
            for (int j = 0; j < n; j++) diff[j] = X[j] - Pi[j];
            double err    = norma(diff);
            double normX  = norma(X);
            double relerr = err / normX;
            if (tol > err || tol > relerr) {
                convergio = true;
                break;
            } else {
                Pi = X.clone();
            }
        }
        // Construir mensaje con el vector solución
        StringBuilder sb = new StringBuilder("Solución: [");
        for (int i = 0; i < n; i++) {
            sb.append(String.format("x%d=%.6f", i + 1, X[i]));
            if (i < n - 1) sb.append(", ");
        }
        sb.append("]");
        double norma = norma(X);
        return new Resultado("Jacobi", norma, iter, convergio, sb.toString());
    }
 
    //  Destructor
    
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("Jacobi destruido.");
        } finally {
            super.finalize();
        }
    }
}