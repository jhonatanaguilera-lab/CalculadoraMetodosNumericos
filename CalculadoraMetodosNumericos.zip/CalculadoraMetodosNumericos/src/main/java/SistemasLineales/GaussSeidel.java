package sistemaslineales;
import core.Resultado;
/**
 * Método iterativo de Gauss-Seidel — RUTINA003.
 * Similar a Jacobi pero usa los valores ya actualizados en la misma iteración,
 * lo que acelera la convergencia.
 */
public class GaussSeidel extends MetodoSistemas {
    
    private double[] P;    // vector de aproximación inicial
    private double   tol;
    private int      m;    // máximo de iteraciones, default 100
 
    //  Constructor
 
    public GaussSeidel(double[][] A, double[] b, double[] P, double tol, int m) {
        super("Gauss-Seidel","Método iterativo que usa los valores ya actualizados en la misma iteración.",A, b);
        this.P = P.clone();
        this.tol = tol;
        this.m = m;
    }
 
    //  Getters y Setters
 
    public double[] getP(){
        return P;
    }
 
    public double getTol(){
        return tol;
    }
    
    public int getM(){
        return m;
    }
    
    //  Setters
    public void setTol(double t){
        this.tol = t;
    }
    
    public void setM(int m){
        this.m = m;
    }
    
    public void setP(double[] P){
        this.P = P.clone();
    }

    //  Utilidades
 
    private double norma(double[] v) {
        double s = 0;
        for (double vi : v) s += vi * vi;
        return Math.sqrt(s);
    }
 
    // Producto punto de una fila de A (sin el índice skip) con X (sin el índice skip)
    private double productoPunto(double[] fila, double[] vec, int skip) {
        double s = 0;
        for (int k = 0; k < fila.length; k++)
            if (k != skip) s += fila[k] * vec[k];
        return s;
    }
 
    //  Algoritmo — traducción directa de RUTINA003
    //  Diferencia clave vs Jacobi: X[j] se actualiza en X (no en copia)
    //  por eso en la siguiente j ya usa el valor recién calculado
 
    @Override
    public Resultado ejecutar() {
        int n = A.length;
        double[] Pi = P.clone();
        double[] X = Pi.clone();   // X empieza igual a P, se actualiza in-place
        int iter = 0;
        boolean convergio = false;
        for (int i = 0; i < m; i++) {
            iter++;
            // Actualizar cada incógnita usando X (ya actualizado en esta iteración)
            for (int j = 0; j < n; j++) {
                X[j] = (b[j] - productoPunto(A[j], X, j)) / A[j][j];
            }
            // Calcular error respecto al paso anterior Pi
            double[] diff = new double[n];
            for (int j = 0; j < n; j++) diff[j] = X[j] - Pi[j];
            double err    = norma(diff);
            double normX  = norma(X);
            double relerr = err / normX;
            if (tol > err || tol > relerr) {
                convergio = true;
                break;
            } else {
                Pi = X.clone();
            }
        }
        // Construir mensaje con el vector solución
        StringBuilder sb = new StringBuilder("Solución: [");
        for (int i = 0; i < n; i++) {
            sb.append(String.format("x%d=%.6f", i + 1, X[i]));
            if (i < n - 1) sb.append(", ");
        }
        sb.append("]");
        double norma = norma(X);
        return new Resultado("Gauss-Seidel", norma, iter, convergio, sb.toString());
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("GaussSeidel destruido.");
        } finally {
            super.finalize();
        }
    }
}