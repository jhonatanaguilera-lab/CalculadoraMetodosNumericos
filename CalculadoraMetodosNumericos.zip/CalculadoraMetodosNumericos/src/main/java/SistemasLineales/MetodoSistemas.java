package sistemaslineales; 
import core.MetodoNumerico;
import core.Resultado;

/**
 * Clase abstracta base para todos los métodos de sistemas lineales.
 * Extiende MetodoNumerico y define atributos comunes.
 */
public abstract class MetodoSistemas extends MetodoNumerico {
 
    protected double[][] A;   // matriz de coeficientes n×n
    protected double[]   b;   // vector de términos independientes
 
    //  Constructor
    public MetodoSistemas(String nombre, String descripcion,double[][] A, double[] b) {
        super(nombre, descripcion);
        this.A = A;
        this.b = b;
    }
 
    //  Getters 
 
    public double[][] getA(){
        return A;
    }
 
    public double[] getB(){
        return b;
    }
 
    //Setters

    public void   setA(double[][] A){
        this.A = A;
    } 
    
    public void   setB(double[] b){
        this.b = b;
    }
    
    //  Método abstracto
 
    @Override
    public abstract Resultado ejecutar();
 
    //  Destructor

    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("MetodoSistemas destruido: " + getNombre());
        } finally {
            super.finalize();
        }
    }
}
 
