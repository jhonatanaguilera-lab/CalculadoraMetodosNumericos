package sistemaslineales;
 
import core.Resultado;
 
/**
 * Eliminación Gauss-Jordan con pivoteo parcial — RUTINA001.
 * Construye internamente la matriz aumentada [A|b].
 * Si el determinante es menor a delta, informa que el sistema no tiene solución única.
 */
public class GaussJordan extends MetodoSistemas {
 
    private double delta;   // tolerancia para detectar sistema singular

    //  Constructor
 
    public GaussJordan(double[][] A, double[] b, double delta) {
        super("Gauss-Jordan","Eliminación con pivoteo parcial para sistemas lineales.",A, b);
        this.delta = delta;
    }
 
    //  Getter
    public double getDelta()          { return delta; }
 
    // Setter
    public void   setDelta(double d)  { this.delta = d; }
    
    //  Utilidad — determinante por regla de Sarrus/cofactores simplificada
    //  Para verificar singularidad usamos el producto de la diagonal
    //  de la matriz triangular resultante (equivalente al det)
 
    private double calcularDet(double[][] matriz) {
        int n = matriz.length;
        double[][] copia = new double[n][n];
        for (int i = 0; i < n; i++)
            copia[i] = matriz[i].clone();
        double det = 1.0;
        for (int j = 0; j < n; j++) {
            // Pivoteo parcial
            int maxFila = j;
            for (int i = j + 1; i < n; i++)
                if (Math.abs(copia[i][j]) > Math.abs(copia[maxFila][j]))
                    maxFila = i;
            double[] tmp = copia[j];
            copia[j] = copia[maxFila];
            copia[maxFila] = tmp;
            if (maxFila != j) det *= -1;
            if (Math.abs(copia[j][j]) < delta) return 0.0;
            det *= copia[j][j];
            for (int i = j + 1; i < n; i++) {
                double k = copia[i][j] / copia[j][j];
                for (int l = j; l < n; l++)
                    copia[i][l] -= k * copia[j][l];
            }
        }
        return det;
    }

    //  Algoritmo — traducción directa de RUTINA001
 
    @Override
    public Resultado ejecutar() {
        int n = A.length;
 
        if (Math.abs(calcularDet(A)) < delta) {
            return new Resultado("Gauss-Jordan", 0, 0, false,"El sistema no tiene solución única (singular o infinitas soluciones).");
        }
 
        // Construir matriz aumentada C = [A|b]
        double[][] C = new double[n][n + 1];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                C[i][j] = A[i][j];
            C[i][n] = b[i];
        }
        // --- Traducción directa de RUTINA001 ---
        int j = -1;
        int i = n - 1;
        while (j < n - 2) {
            if (i == n - 1) {
                j++;
                i = j;
                // Subcol = valores absolutos de la columna j desde fila j
                double[] subcol = new double[n - j];
                for (int r = 0; r < n - j; r++)
                    subcol[r] = Math.abs(C[j + r][j]);
                // t = índice del máximo en subcol
                int t = 0;
                for (int r = 1; r < subcol.length; r++)
                    if (subcol[r] > subcol[t]) t = r;
                double pibot = subcol[t];
                if (delta > pibot) {
                    return new Resultado("Gauss-Jordan", 0, 0, false,
                            "El sistema no tiene solución única (pivote menor a delta).");
                } else {
                    // Intercambiar filas j y t+j
                    double[] aux = C[j].clone();
                    C[j]     = C[t + j];
                    C[t + j] = aux;
                }
            }
            i++;
            double k = C[i][j] / C[j][j];
            for (int col = j; col <= n; col++)
                C[i][col] -= k * C[j][col];
        }
        // Sustitución regresiva
        double[] X = new double[n];
        X[n - 1] = C[n - 1][n] / C[n - 1][n - 1];
        for (int ii = n - 2; ii >= 0; ii--) {
            double suma = 0;
            for (int jj = ii + 1; jj < n; jj++)
                suma += C[ii][jj] * X[jj];
            X[ii] = (C[ii][n] - suma) / C[ii][ii];
        }
        // Construir mensaje con el vector solución
        StringBuilder sb = new StringBuilder("Solución: [");
        for (int ii = 0; ii < n; ii++) {
            sb.append(String.format("x%d=%.6f", ii + 1, X[ii]));
            if (ii < n - 1) sb.append(", ");
        }
        sb.append("]");
        // valorFinal = norma del vector solución
        double norma = 0;
        for (double xi : X) norma += xi * xi;
        norma = Math.sqrt(norma);
        return new Resultado("Gauss-Jordan", norma, 0, true, sb.toString());
    }
 
    //  Destructor
 
    @Override
    @SuppressWarnings("deprecation")
    protected void finalize() throws Throwable {
        try {
            System.out.println("GaussJordan destruido.");
        } finally {
            super.finalize();
        }
    }
}
